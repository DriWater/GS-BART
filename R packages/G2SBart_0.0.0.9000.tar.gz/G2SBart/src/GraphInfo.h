#pragma once

#ifdef _OPENMP
#include <omp.h>
#endif
// [[Rcpp::plugins(openmp)]]
#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]



class GraphInfo {
public:
  unsigned int nc; // Row index: one for each leaf node/cluster in the decision tree
  // unsigned int k; // Column index: one for each response dimension (1 for MSE/binary classification)
  unsigned int vtx; // Column index: one for each vertex
  arma::mat Gs_R;
  arma::mat Hs_R;
  arma::mat Hs_mu_R;
  arma::umat cnt_R;
  arma::umat Prop; // whether a split is proper or not

  
  GraphInfo(const unsigned int nc_inp, const unsigned int v_inp):nc(nc_inp), vtx(v_inp) {
    Gs_R = arma::mat(nc_inp, v_inp, arma::fill::zeros);
    Hs_R = arma::mat(nc_inp, v_inp, arma::fill::zeros);
    Hs_mu_R = arma::mat(nc_inp, v_inp, arma::fill::zeros);
    cnt_R = arma::umat(nc_inp, v_inp, arma::fill::zeros);
    Prop = arma::umat(nc_inp, v_inp, arma::fill::zeros);
  }
  
  GraphInfo(const GraphInfo &other):nc(other.nc), vtx(other.vtx){
    Gs_R = other.Gs_R;
    Hs_R = other.Hs_R;
    Hs_mu_R = other.Hs_mu_R;
    cnt_R = other.cnt_R;
    Prop = other.Prop;
  }
  
  GraphInfo& operator=(const GraphInfo &other){
    vtx = other.vtx;
    nc = other.nc;
    Gs_R = other.Gs_R;
    Hs_R = other.Hs_R;
    Hs_mu_R = other.Hs_mu_R;
    cnt_R = other.cnt_R;
    Prop = other.Prop;
    return *this;
  }
  
  GraphInfo operator+(const GraphInfo &other) const {
    GraphInfo result(nc, vtx);
    result.Gs_R = Gs_R + other.Gs_R;
    result.Hs_R = Hs_R + other.Hs_R;
    result.Hs_mu_R = Hs_mu_R + other.Hs_mu_R;
    result.cnt_R = cnt_R + other.cnt_R;
    result.Prop = Prop + other.Prop;
    return(result);
  }
  
  GraphInfo& operator+=(const GraphInfo &other) {
    Gs_R += other.Gs_R;
    Hs_R += other.Hs_R;
    Hs_mu_R += other.Hs_mu_R;
    cnt_R += other.cnt_R;
    Prop += other.Prop;
    return *this;
  }
};

#ifdef _OPENMP
#pragma omp declare reduction( + : GraphInfo : omp_out = omp_out + omp_in ) initializer (omp_priv=omp_orig)
#endif

