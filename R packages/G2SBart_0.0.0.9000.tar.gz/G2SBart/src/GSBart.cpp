#include "GSBart.h"

// [[Rcpp::export]]
Rcpp::List GenGSBart(Rcpp::NumericVector Y_train,
                      const unsigned int ndpost,
                      const unsigned int nskip,
                      const unsigned int nkeep,
                      Rcpp::List Graphs, Rcpp::NumericVector graphs_weight,
                      Rcpp::List Hyperpars,
                      Rcpp::List Modelpars,
                      const unsigned int model,
                      const unsigned int nthreads,
                      const bool pred_flag,
                      const bool dart, 
                      const bool const_theta,
                      const bool verbose, int seed){
  set_rng_seed(seed);                    
  DEBUG_MSG("Entered fitGSBart");
  //Read in all values from Hyperpars
  // Learning rate
  // L2 regularization term on leaf node weights
  const double alpha = Rcpp::as<double>(Hyperpars["alpha"]);
  const double beta = Rcpp::as<double>(Hyperpars["beta"]);
  const double a =  Rcpp::as<double>(Hyperpars["a"]);
  double b = Rcpp::as<double>(Hyperpars["b"]);
  const unsigned int split_eps = Rcpp::as<unsigned int>(Hyperpars["split_eps"]);
  const unsigned int max_depth = Rcpp::as<unsigned int>(Hyperpars["max_depth"]);
  const double rb = Rcpp::as<double>(Hyperpars["rb"]);
  const double mu0 = Rcpp::as<double>(Hyperpars["mu0"]);
  const unsigned int tree_iter  = Rcpp::as<unsigned int>(Hyperpars["tree_iter"]);
  const double eta = Rcpp::as<double>(Hyperpars["eta"]);
  const double zeta = Rcpp::as<double>(Hyperpars["zeta"]);
  double rho = Rcpp::as<double>(Hyperpars["rho"]);
  double theta = Rcpp::as<double>(Modelpars["theta"]);
  double tausq = Rcpp::as<double>(Modelpars["tausq"]);
  DEBUG_MSG("Read in Hyperpars");
  //Read in all values from Y, Y_ho and Graphs
  const unsigned int n = Y_train.length();
  // const unsigned int n_ho = Y_test.length();
  arma::vec Y = Rcpp::as<arma::vec>(Y_train);
  // arma::vec Y_ho = Rcpp::as<arma::vec>(Y_test);
  arma::vec weight_vec = Rcpp::as<arma::vec>(graphs_weight);
  std::vector<double> lgw = arma::conv_to<std::vector<double>>::from(arma::log(weight_vec));
  // arma::vec log_weight_vec = arma::log(Rcpp::as<arma::vec>(graphs_weight));
  // turning all the values in Graphs into RootGraphs
  // Outer vector goes from 0 < n_rounds, inner vectors go from 0 < n_graphs
  std::vector<std::vector<OST> > inputGraphs; //(n_rounds, std::vector<RootGraph>(n_graphs));
  DEBUG_MSG("Declared inputGraphs");
  if(pred_flag){
    for(Rcpp::List GraphRound : Graphs) {
      std::vector<OST> tmpGraphs;
      //DEBUG_MSG("Declared tmpGraphs");
      for(Rcpp::List GGraph : Rcpp::List(GraphRound)) {
        if(Rcpp::IntegerVector(GGraph["tr2mesh"]).length() != n) {
          Rcpp::stop("All input graphs must map every observation in Y to a vertex using tr2mesh");
        }
        tmpGraphs.emplace_back(adj_list_from_R_list(Rcpp::as<Rcpp::List>(GGraph["children"])),
                              adj_list_from_R_list(Rcpp::as<Rcpp::List>(GGraph["mesh2tr"])),
                              adj_list_from_R_list(Rcpp::as<Rcpp::List>(GGraph["mesh2ho"])),
                              Rcpp::as<std::vector<unsigned int> >(Rcpp::IntegerVector(GGraph["tr2mesh"])),
                              Rcpp::as<std::vector<unsigned int> >(Rcpp::IntegerVector(GGraph["root"])));
        //DEBUG_MSG("Emplaced a tmpGraph");
      }
      inputGraphs.emplace_back(tmpGraphs);
      //DEBUG_MSG("Emplaced tmpGraphs");
    }
  }else{
    for(Rcpp::List GraphRound : Graphs) {
      std::vector<OST> tmpGraphs;
      //DEBUG_MSG("Declared tmpGraphs");
      for(Rcpp::List GGraph : Rcpp::List(GraphRound)) {
        if(Rcpp::IntegerVector(GGraph["tr2mesh"]).length() != n) {
          Rcpp::stop("All input graphs must map every observation in Y to a vertex using tr2mesh");
        }
        tmpGraphs.emplace_back(adj_list_from_R_list(Rcpp::as<Rcpp::List>(GGraph["children"])),
                              adj_list_from_R_list(Rcpp::as<Rcpp::List>(GGraph["mesh2tr"])),
                              Rcpp::as<std::vector<unsigned int> >(Rcpp::IntegerVector(GGraph["tr2mesh"])),
                              Rcpp::as<std::vector<unsigned int> >(Rcpp::IntegerVector(GGraph["root"])));
      }
      inputGraphs.emplace_back(tmpGraphs);
    }
  }
  DEBUG_MSG("Read in Graphs");
  fitOutput ret = fitGSBart(Y, inputGraphs, lgw, model, ndpost, nskip, nkeep, nthreads, tree_iter, 
                            split_eps, max_depth, alpha, beta, rb, a, b, eta, zeta, rho, tausq, mu0, 
                            theta, dart, const_theta, verbose);

  // Create output and return
  Rcpp::List OutputList;
  DEBUG_MSG("Creating OutputList and returning");
  if(pred_flag){
    OutputList = Rcpp::List::create(
    Rcpp::Named("phi.train") = ret.trdraw,
    Rcpp::Named("phi.test") = ret.tedraw,
    Rcpp::Named("varcount") = ret.varcnt,
    Rcpp::Named("tau") = ret.taudraw,
    // Rcpp::Named("tree.depth") = ret.treedepth,
    Rcpp::Named("tree.draws") = Rcpp::CharacterVector(ret.treelist)
    );
    return(OutputList);
  }else{
    OutputList = Rcpp::List::create(
      Rcpp::Named("phi.train") = ret.trdraw,
      Rcpp::Named("varcount") = ret.varcnt,
      Rcpp::Named("tau") = ret.taudraw,
      // Rcpp::Named("tree.depth") = ret.treedepth,
      Rcpp::Named("tree.draws") = Rcpp::CharacterVector(ret.treelist)
    );
    return(OutputList);
  }
  return(OutputList);
}

std::vector<std::vector<unsigned int>> adj_list_from_R_list(const Rcpp::List &adj_list) {
  // get the number of vertices in the graph
  int num_vertices = adj_list.size();

  // initialize the adjacency list
  std::vector<std::vector<unsigned int>> adj(num_vertices);

  // iterate over the vertices in the list
  for (int i = 0; i < num_vertices; i++) {
    // get the vector of child vertices for this vertex
    Rcpp::IntegerVector children = adj_list[i];

    // convert the child vector to a std::vector and add it to the adjacency list
    std::vector<unsigned int> child_vec(children.begin(), children.end());
    adj[i] = child_vec;
  }

  return adj;
}

void set_rng_seed(int seed) {
  Rcpp::Environment base = Rcpp::Environment::base_env();
  Rcpp::Function set_seed = base["set.seed"]; 
  set_seed(seed); 
  GetRNGstate(); 
  PutRNGstate();  
}
