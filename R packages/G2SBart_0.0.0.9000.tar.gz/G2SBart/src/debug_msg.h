#pragma once

#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
#include <ostream>

//#define GSBART_DEBUG

#ifdef GSBART_DEBUG
#undef _OPENMP
//Rcpp::Environment base = Rcpp::Environment("package:base");
//Rcpp::Function readline = base["readline"];

#define DEBUG_MSG(str) ;do { Rcpp::Rcout << "GSBART_DEBUG: " << str << std::endl; /*readline("");*/} while( false );
#else
#define DEBUG_MSG(str) /*do { ;//do nothing } while ( false );*/;;
#endif
