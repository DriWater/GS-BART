#pragma once
// #define GSBART_DEBUG
#include <vector>
#include <utility>
#include <iterator>
#include <valarray>
#include <set>
#include <ostream>
#include <stdexcept>
#include <algorithm>

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include <RcppArmadillo.h>

#ifdef _OPENMP
#include <omp.h>
#endif
// [[Rcpp::plugins(openmp)]]

#include "utilfuncs.h"
#include "debug_msg.h"

typedef struct {
  arma::mat trdraw;
  arma::mat tedraw;
  arma::umat varcnt; 
  arma::vec taudraw;
  std::string treelist;
} fitOutput;

fitOutput fitGSBart(arma::vec Y, std::vector<std::vector<OST>> &inputGraphs, std::vector<double> &lgw, const unsigned int model,
                    const unsigned int ndpost, const unsigned int nskip, const unsigned int nkeep, const unsigned int nthreads, 
                    const unsigned int tree_iter, const unsigned int split_eps, const unsigned int max_depth, const double alpha, 
                    const double beta, const double rb, const double a, double b, const double eta, const double zeta, const double rho, 
                    double tausq, double mu0, double theta, const bool dart, const bool const_theta, const bool verbose);
