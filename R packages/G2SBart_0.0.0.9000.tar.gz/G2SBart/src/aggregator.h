#pragma once

#include <vector>
#include <unordered_map>
#include <functional>
#include <utility>
#include <cstddef>
#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]

template <typename T, typename G>
std::pair<std::vector<std::vector<T>>, 
          std::vector<std::vector<G>>> groupBy(const std::vector<std::vector<T>>& toReduce, 
                                               const std::vector<std::vector<G>>& groups, 
                                               std::function<T(T, T)> reduceFunc);

std::pair<arma::mat, arma::umat> groupBy(const arma::mat& toReduce, 
                              const arma::umat& groups, 
                              std::function<arma::rowvec(arma::rowvec, 
                                                    arma::rowvec)> reduceFunc);
                                                      

std::pair<arma::mat, arma::umat> groupBy(const arma::mat& toReduce, 
                              const arma::umat& groups);                                                        

template <typename T>
struct VectorHasher {
  std::size_t operator()(const std::vector<T>& vec) const {
    std::size_t seed = vec.size();
    for (const auto& elem : vec) {
      seed ^= std::hash<T>{}(elem) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
    }
    return seed;
  }
};

struct ArmaHasher {
  std::size_t operator()(const arma::urowvec& vec) const {
    std::size_t seed = vec.size();
    for (const auto& elem : vec) {
      seed ^= std::hash<unsigned int>{}(elem) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
    }
    return seed;
  }
};

struct ArmaKeyEqual {
  bool operator()(const arma::urowvec &lhs, const arma::urowvec &rhs) const {
    return (arma::all(lhs == rhs));
  }
};

template<typename T, typename G>
using GroupByMap = std::unordered_map<std::vector<G>, std::vector<T>, VectorHasher<G>>;


