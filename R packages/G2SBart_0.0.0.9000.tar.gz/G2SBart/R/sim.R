#' An U-shape Simulation Dataset
#'
#' @description A dataset containing an oriented spanning tree generated from a U-shape manifold,
#' along with unstructured covariates, different types of response data, hyperparameters,
#' model parameters, corresponding graph weights, and additional elements.
#'
#' @format A list containing the following objects:
#' \describe{
#'   \item{Graphs}{A list of oriented spanning trees.}
#'   \item{Y}{Numeric vector representing the continuous training response data.}
#'   \item{Y_ho}{Numeric vector representing the continuous testing response data.}
#'   \item{hyperpar}{List of hyperparameters used in the simulation.}
#'   \item{modelpar}{List of model parameters for the simulation.}
#'   \item{graphs_weight}{Numeric vector specifying graph weights.}
#'   ...
#' }
#'
"sim"
