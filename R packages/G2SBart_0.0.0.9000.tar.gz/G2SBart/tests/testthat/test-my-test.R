# library(testthat)
# library(purrr)
# library(dplyr)
# load('~/Downloads/code/test_code/testUshapecnt.Rdata')
# repetitions = 1
# n_rounds= 50

# for(i in 1:length(InputGraphs)){
#   for(j in 1:length(InputGraphs[[i]])){
#     InputGraphs[[i]][[j]]$mesh2tr <- InputGraphs[[i]][[j]]$mesh2trList
#     InputGraphs[[i]][[j]]$mesh2ho <- InputGraphs[[i]][[j]]$mesh2hoList
#     # InputGraphs[[i]][[j]]$mesh2ho <- NULL
#     InputGraphs[[i]][[j]]$mesh2trList <- NULL
#     InputGraphs[[i]][[j]]$mesh2hoList <- NULL
#     InputGraphs[[i]][[j]]$ho2mesh <- NULL
#   }
# }

# sim.list = vector(mode = "list", length = repetitions)
# for(repetition in 1:repetitions){
#   set.seed(1234+repetition)
#   message("Sampling Y")
#   sim$Y0 = exp((sim$f_true+7)/3)
#   sim$Y0_ho = exp((sim$f_ho_true+7)/3)
#   sim$Y <- rpois(800, sim$Y0)
#   sim$Y_ho <- rpois(200, sim$Y0_ho)
#   hyperpar['b'] = 0.5*var(log(sim$Y+.01))/n_rounds;
#   nu = 3; q = 0.9;  quant = qchisq(1-q, nu)
#   hyperpar['lambda'] = (var(log(sim$Y+.01))*quant)/nu
#   hyperpar['mu0'] = mean(log(sim$Y+0.01))/n_rounds
#   hyperpar['eta'] = .5
#   hyperpar['zeta'] = 1
#   hyperpar['split_eps'] = 0
#   modelpar['theta'] = 0.1
#   hyperpar['rho'] = length(InputGraphs[[1]])
#   GSBart_Time = Sys.time()
#   GSBres <- GenGSBart(sim$Y, 25, 15, 25, InputGraphs, graphs_weight, hyperpar, modelpar, 2, 7, pred_flag = T, dart = T, const_theta = F, verbose = T, seed = 1234)
#   GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
#   GSBart_RMSE = sqrt(mean((sim$Y0_ho - exp(colMeans(GSBres$phi.test)))^2))
#   GSBart_MSE = mean((sim$Y0_ho - exp(colMeans(GSBres$phi.test)))^2)
#   sim.list[[repetition]] = data.frame(
#     models = c("GSBart"),
#     RMSE = c(GSBart_RMSE),
#     MSE = c(GSBart_MSE),
#     times = c(GSBart_Time),
#     sim = c(repetition)
#   )
# }

# save(sim.list, file = "~/Downloads/GSBart_rebuttal/Ushape/GSBUshaperes.Rdata")

# sim.summary = sim.list %>%
#   list_rbind() %>%
#   group_by(models) %>%
#   summarise(across(c('RMSE', 'MSE', 'times'),
#                    list("mean" = mean, "sd" = sd),
#                    .names = "{.col}_{.fn}")) %>%
#   arrange(match(models, c("GSBart"), desc(models)))

# print(sim.summary)

# save(sim.list, sim.summary, file = "~/Downloads/GSBart_rebuttal/Ushape/GSBUshaperes.Rdata")

# library(testthat)
# load('~/Downloads/code/test_code/whitenoisecntdata.Rdata')
# hyperpar['max_depth'] = 9
# hyperpar['alpha'] = 0.95
# hyperpar['beta'] = 2
# hyperpar['tree_iter'] = 16

# tmp <- GenGSBart(y_cnt, 15, 25, 15, InputGraphs, graphs_weight, hyperpar, modelpar, 2, 6, verbose = T)
# # print(mean((sim$Y_ho - colMeans(tmp$phi.test))^2))
# print(tmp$sigma)
# print(tmp$tau)
# print(tmp$tree.draws)


# library(testthat)
# load('~/Downloads/code/test_code/USCancer.Rdata')
# n_rounds = length(InputGraphs)
# hyperpar['tree_iter'] = 20; hyperpar['max_depth'] = 10
# hyperpar['b'] = 0.5*var(log(Y/(2*exp(offset_train))+.01))/n_rounds
# modelpar['tausq']  = (6/(2*sqrt(n_rounds)))^2
# GSBart_Time = Sys.time()
# GSBart_Fit <- GenGSBart(Y/(2*exp(offset_train)), 10, 10, 10*n_rounds, InputGraphs, graphs_weight,
#                         hyperpar, modelpar, 2, 9, verbose = T, seed = 1234)
# GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
# GSBart_RMSE = sqrt(mean((Y_ho - exp(colMeans(GSBart_Fit$phi.test))*2*exp(offset_test))^2))
# print(GSBart_RMSE); print(GSBart_Time)

# par_grid = expand.grid(
#   tausq = (seq(1,6, 0.5)/(2*sqrt(50)))^2,
#   a = 5
# )
# repetitions = nrow(par_grid)
# sim.list = parallel::mclapply(1:repetitions, function(repetition){
#   modelpar['tausq'] = par_grid[repetition,1]
#   hyperpar['a'] = par_grid[repetition,2]
#   GSBart_Time = Sys.time()
#   GSBart_Fit <- GenGSBart(Y/(2*exp(offset_train)), 25, 15, 1250, InputGraphs, graphs_weight,
#                           hyperpar, modelpar, 2, 1, verbose = F, seed = 1234)
#   GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
#   GSBart_RMSE = sqrt(mean((Y_ho - exp(colMeans(GSBart_Fit$phi.test))*2*exp(offset_test))^2))
#   sim_results_df = data.frame(
#     models = c("GSBart"),
#     MSPE = c(GSBart_RMSE),
#     times = c(GSBart_Time),
#     sim = rep(repetition, 1)
#   )
#   return(sim_results_df)
# }, mc.cores = 8)
# save(sim.list, file = "~/Downloads/GSBart_rebuttal/USCancer/GSBUSCancerres1.Rdata")


# library(testthat)
# load('~/Downloads/code/test_code/AirPollution.Rdata')
# hyperpar['tree_iter'] = 30; hyperpar['max_depth'] = 15
# n_rounds = length(InputGraphs)
# modelpar['tausq'] = (3/(2*sqrt(length(InputGraphs))))^2
# hyperpar['b'] = 0.5 * 6 / n_rounds
# USAir <- GenGSBart(Y_bin, 25, 15, 25*n_rounds, InputGraphs, graphs_weight,
#                    hyperpar, modelpar, 1, 8, verbose = T, seed = 1234)      
# y_hat <- exp(colMeans(USAir$phi.test))/(1+exp(colMeans(USAir$phi.test)))
# y_hat <- as.numeric(y_hat > 0.5)
# Y_bin_ho_tmp <- na.omit(Y_bin_ho)
# remove.id = which(is.na(Y_bin_ho))
# y_hat_tmp <- y_hat[-remove.id]
# print(mean(y_hat_tmp == Y_bin_ho_tmp))

# library(testthat)
# load('~/Downloads/code/test_code/USFlood.Rdata')
# USFlood<- GenGSBart(Y, 25, 15, 2500, InputGraphs, graphs_weight,
#                    hyperpar, modelpar, 1, 6, verbose = T, seed = 1145)
# # save(USFlood, file = "~/Downloads/GSBart_rebuttal/USFlood/USFlood.Rdata")         
# y_hat <- exp(colMeans(USFlood$phi.test))/(1+exp(colMeans(USFlood$phi.test)))
# y_hat <- as.numeric(y_hat > 0.5)
# print(mean(y_hat == Y_ho))


# library(testthat)
# library(purrr)
# library(dplyr)
# load('~/Downloads/code/test_code/testToruscnt.Rdata')
# repetitions = n_rounds = 50
# sim.list = vector(mode = "list", length = repetitions)
# for(repetition in 1:repetitions){
#   set.seed(1234+repetition)
#   message("Sampling Y")
#   sim$Y0 <- exp((sim$f_true + 17)/8)
#   sim$Y0_ho <- exp((sim$f_ho_true + 17)/8)
#   sim$Y <- rpois(500, sim$Y0)
#   sim$Y_ho <- rpois(200, sim$Y0_ho)
#   hyperpar['b'] = 0.5*var(log(sim$Y+.01))/n_rounds
#   nu = 3; q = 0.9;  quant = qchisq(1-q, nu)
#   hyperpar['lambda'] = (var(log(sim$Y+.01))*quant)/nu
#   hyperpar['mu0'] = mean(log(sim$Y+0.01))/n_rounds
#   GSBart_Time = Sys.time()
#   GSBres <- GenGSBart(sim$Y, 25, 15, 1250, InputGraphs, graphs_weight, hyperpar, modelpar, 2, 7, verbose = F, seed = 1234)
#   GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
#   GSBart_RMSE = sqrt(mean((sim$Y0_ho - exp(colMeans(GSBres$phi.test)))^2))
#   GSBart_MSE = mean((sim$Y0_ho - exp(colMeans(GSBres$phi.test)))^2)
#   sim.list[[repetition]] = data.frame(
#     models = c("GSBart"),
#     RMSE = c(GSBart_RMSE),
#     MSE = c(GSBart_MSE),
#     times = c(GSBart_Time),
#     sim = c(repetition)
#   )
# }

# save(sim.list, file = "~/Downloads/GSBart_rebuttal/Torus/GSBToruscntres.Rdata")

# sim.summary = sim.list %>%
#   list_rbind() %>%
#   group_by(models) %>%
#   summarise(across(c('RMSE', 'MSE', 'times'),
#                    list("mean" = mean, "sd" = sd),
#                    .names = "{.col}_{.fn}")) %>%
#   arrange(match(models, c("GSBart"), desc(models)))

# print(sim.summary)
# save(sim.list, sim.summary, file = "~/Downloads/GSBart_rebuttal/Torus/GSBToruscntres.Rdata")

# library(dplyr)
# library(caret)
# library(purrr)
# library(testthat)
# library(parallel)

# mgsbart2 <- function(Y_train, InputGraphs, ndpost, nskip, nkeep = ndpost*length(Graphs), graphs_weight = rep(1/length(Graphs[1]), length(Graphs[1])),
#                      hyperpar = NULL, modelpar = NULL, nthreads = 0, dart = FALSE, const_theta = TRUE,  verbose = FALSE, seed = 1234){
#   cats <- sort(unique(Y_train))
#   K <- length(cats)
#   ntrees = length(InputGraphs)
#   pred_flag = !is.null(InputGraphs[[1]][[1]]$ho2mesh)
#   if(K<2)
#     stop("there must be at least 2 categories")
#   post <- list()
#   post$K <- K
#   post$cats <- cats

#   N <- length(Y_train)

#   post$phi.train <- matrix(nrow=nkeep, ncol=N*K)
#   post$prob.train <- matrix(nrow=nkeep, ncol=N*K)
#   # post$tot.train <- matrix(0, nrow=nkeep, ncol=N)
#   if(pred_flag) {
#     # Q <- length(igraph::graph.attributes(Graphs[[1]][[1]]$g)$ho2mesh)
#     Q <- length(InputGraphs[[1]][[1]]$ho2mesh)
#     post$phi.test <- matrix(0, nrow=nkeep, ncol=Q*K)
#     post$prob.test <- matrix(0, nrow=nkeep, ncol=Q*K)
#     # post$tot.test <- matrix(0, nrow=nkeep, ncol=Q)
#   }

#   post$varcount <- as.list(1:K)
#   # post$varimp <- matrix(nrow=K, ncol=P)
#   post.list <- as.list(1:K)
#   post$tau <- as.list(1:K)
#   post$tree.draws.list <- as.list(1:K)
#   if(nthreads >= 2*K){
#     nthreads.inn = floor(nthreads/K)
#     nthreads.outer = K
#   }else{
#     nthreads.inn = 0
#     nthreads.outer = nthreads
#   }

#   post.list = parallel::mclapply(1:K, function(h){
#     # Y_train_h = (Y_train==cats[h])*0.99
#     # Y_train_h[Y_train_h==0] = 0.01
#     Y_train_h = (Y_train==cats[h])
#     hyperpar_h = hyperpar
#     modelpar_h = modelpar
#     if(!is.null(hyperpar_h)){
#       hyperpar_h_names = names(hyperpar_h)
#       if(!("alpha" %in% hyperpar_h_names)){ hyperpar_h["alpha"] = 0.95}
#       if(!("beta" %in% hyperpar_h_names)){hyperpar_h["beta"] = 2}
#       if(!("a" %in% hyperpar_h_names)){hyperpar_h["a"] = 3}
#       if(!("b" %in% hyperpar_h_names)){hyperpar_h["b"] = 0.5 * 6 / ntrees}
#       if(!("split_eps" %in% hyperpar_h_names)){ hyperpar_h["split_eps"] = 0}
#       if(!("max_depth" %in% hyperpar_h_names)){ hyperpar_h["max_depth"] = 6}
#       if(!("rb" %in% hyperpar_h_names)){hyperpar_h["rb"] = 0.5}
#       if(!("mu0" %in% hyperpar_h_names)){hyperpar_h["mu0"] =  stats::qlogis(mean(Y_train_h))/ntrees}
#       if(!("eta" %in% hyperpar_h_names)){hyperpar_h["eta"] = 0.5}
#       if(!("zeta" %in% hyperpar_h_names)){hyperpar_h["zeta"] = 1}
#       if(!("rho" %in% hyperpar_h_names)){hyperpar_h["rho"] = length(Graphs[[1]])}
#       if(!("tree_iter" %in% hyperpar_h_names)){hyperpar_h["tree_iter"] = 12}
#     }else{
#       hyperpar_h = list(alpha = 0.95, beta = 2, a = 3, b = 0.6, split_eps = 0, max_depth = 6, rb = 0.5, mu0 = stats::qlogis(mean(Y_train_h))/ntrees, tree_iter = 15)
#     }
#     if(!is.null(modelpar_h)){
#       modelpar_names = names(modelpar_h)
#       if(!("tausq" %in% modelpar_names)){modelpar_h["tausq"] = ((max(Y_train_h)-min(Y_train_h))/(2*2*sqrt(ntrees)))^2 }
#       if(!("theta" %in% modelpar_names)){modelpar_h["theta"] = 0.1}
#     }else{      
#       modelpar_h = list("tausq" = ((max(Y_train)-min(Y_train))/(2*sqrt(ntrees)))^2,
#                         "theta" = 0.1)
#     }
#     ret = GenGSBart(Y_train_h, ndpost, nskip, nkeep, InputGraphs, graphs_weight, hyperpar_h, modelpar_h,
#                     1, nthreads.inn, dart, const_theta, verbose, seed)
#     return(ret)
#   }, mc.cores = nthreads.outer)
#   for(h in 1:K) {
#     for(i in 1:N) {
#       j <- (i-1)*K+h
#       post$phi.train[ , j] <- post.list[[h]]$phi.train[ , i]
#       # post$tot.train[ , i] <-
#       #   post$tot.train[ , i]+exp(post$phi.train[ , j])
#       if(h==K){
#         maxvals = apply(post$phi.train[ ,(i-1)*K+1:K], 1, max)
#         tot.train = apply(post$phi.train[ ,(i-1)*K+1:K], 1, function(x){
#                           maxval <- max(x);  sum(exp(x - maxval))})
#         post$prob.train[ , (i-1)*K+1:K] = exp(post$phi.train[, (i-1)*K+1:K] 
#                                         - maxvals)/tot.train                
#       }
#     }
#     if(pred_flag) {
#       for(i in 1:Q) {
#         j <- (i-1)*K+h
#         post$phi.test[ , j] <- post.list[[h]]$phi.test[ , i]
#         if(h==K){
#           maxvals = apply(post$phi.test[ ,(i-1)*K+1:K], 1, max)
#           tot.test = apply(post$phi.test[ ,(i-1)*K+1:K], 1, function(x){
#                            maxval <- max(x);  sum(exp(x - maxval))})
#           post$prob.test[ , (i-1)*K+1:K] = exp(post$phi.test[, (i-1)*K+1:K] 
#                                           - maxvals)/tot.test         
#         }
#       }
#     }
#     post$varcount[[h]] <- post.list[[h]]$varcount
#     post$tau[[h]] <- post.list[[h]]$tau
#     post$tree.draws.list[[h]] <- post.list[[h]]$tree.draws
#   }
#   post$prob.train.mean <- apply(post$prob.train, 2, mean)
#   post$yhat.train = max.col(matrix(post$prob.train.mean, ncol = K, byrow = T)) - 1
#   post$call = call
#   if(pred_flag) {
#     post$prob.test.mean <- apply(post$prob.test, 2, mean)
#     post$yhat.test = max.col(matrix(post$prob.test.mean, ncol = K, byrow = T)) - 1
#   }
#   return(post)
# }

# Standardize = function(Y, std_par = NULL) {
#   if(is.null(std_par)) {
#     ymean = mean(Y)
#     yscale = 2 * max(abs(Y))
#   } else {
#     ymean = std_par['mean']
#     yscale = std_par['scale']
#   }
#   Y = (Y - ymean) / yscale
#   std_par = c('mean' = ymean, 'scale' = yscale)
#   return(list(Y = Y, std_par = std_par))
# }

# load("~/Downloads/code/test_code/testUshapemult.Rdata")

# # repetitions = c(3, 13, 19, 20, 23, 24, 33, 47, 50)
# # repetitions = c(1:10)
# repetitions = c(16)
# sim.list = vector(mode = "list", length = length(repetitions))
# n = nrow(sim$X)
# n_ho = nrow(sim$X_ho)
# hyperpar['tree_iter'] = 30; hyperpar['max_depth'] = 15

# sigmasq_y = 0.15 # Ushape

# for(i in 1:length(repetitions)){
#   repetition = repetitions[i]
#   set.seed(1234+repetition)
#   message("Sampling Y")
#   Y0 = sim$f_true + rnorm(n, 0, sigmasq_y)
#   Y0_ho = sim$f_ho_true + rnorm(n_ho, 0, sigmasq_y)

#   ## standardize data
#   stdY = Standardize(Y0)
#   sim$Y = stdY$Y
#   sim$Y_ho = (Y0_ho - stdY$std_par['mean']) / stdY$std_par['scale'] 

#   multinom_resp = as.numeric(cut(sim$Y,c(-Inf,quantile(sim$Y,c(.2,.3,.65,.8)),Inf),labels=1:5))-1
#   multinom_resp_test =as.numeric(cut(sim$Y_ho,c(-Inf,quantile(sim$Y,c(.2,.3, .65,.8)),Inf),labels=1:5))-1
#   K = length(unique(multinom_resp))
#   message("Fitting GSBART")
#   MGSB_Time = Sys.time()
#   MGSB_Fit = mgsbart2(multinom_resp, InputGraphs, 25, 15, nkeep = 1250,
#                       graphs_weight, hyperpar, modelpar, nthreads = 1, seed = 1234)
#   save(MGSB_Fit, file = paste0("~/Downloads/GSBart_rebuttal/Ushape/MGSB_Fit", repetition, ".Rdata"))
#   MGSB_Time = Sys.time() - MGSB_Time
#   MGSB_y_test = MGSB_Fit$yhat.test
#   MGSB_ACC = mean(MGSB_y_test == multinom_resp_test)
#   MGSB_CM = confusionMatrix(factor(MGSB_y_test, levels = (0:(K - 1))),
#                             factor(multinom_resp_test, levels = (0:(K - 1))))
#   sim.list[[i]] = data.frame(
#     models = c("GSBART"), ACC = c(MGSB_ACC),
#     times = c(MGSB_Time), sim = c(repetition)
#   )
# }

# # save(sim.list, file = "~/Downloads/GSBart_rebuttal/Ushape/GSBUshapemultres4.Rdata")

# # save(sim.list, file = "~/Downloads/GSBart_rebuttal/Torus/GSBTorusmultres.Rdata")

# sim.summary = sim.list%>%
#   list_rbind() %>%
#   group_by(models) %>%
#   summarise(across(c('ACC', 'times'),
#                    list("mean" = mean, "sd" = sd),
#                    .names = "{.col}_{.fn}")) %>%
#   arrange(match(models, c("GSBART"), desc(models)))

# print(sim.summary)
# save(sim.list, sim.summary, file = "~/Downloads/GSBart_rebuttal/Ushape/GSBUshapemultres4.Rdata")

# save(sim.list, sim.summary, file = "~/Downloads/GSBart_rebuttal/Torus/GSBTorusmultres.Rdata")


# load("~/Downloads/code/test_code/testTorusmultorg.Rdata")

# repetitions = c(1:50)

# sim.list = vector(mode = "list", length = length(repetitions))
# n = nrow(sim$X); n_ho = nrow(sim$X_ho)
# hyperpar['tree_iter'] = 30; hyperpar['max_depth'] = 15

# sigmasq_y = 0.1 # Torus

# for(i in 1:length(repetitions)){
#   repetition = repetitions[i]
#   set.seed(1234+repetition)
#   message("Sampling Y")
#   Y0 = sim$f_true + rnorm(n, 0, sigmasq_y)
#   Y0_ho = sim$f_ho_true + rnorm(n_ho, 0, sigmasq_y)

#   ## standardize data
#   stdY = Standardize(Y0)
#   sim$Y = stdY$Y
#   sim$Y_ho = (Y0_ho - stdY$std_par['mean']) / stdY$std_par['scale'] 

#   multinom_resp = as.numeric(cut(sim$Y,c(-Inf,quantile(sim$Y,c(.2,.3,.65,.8)),Inf),labels=1:5))-1
#   multinom_resp_test =as.numeric(cut(sim$Y_ho,c(-Inf,quantile(sim$Y,c(.2,.3, .65,.8)),Inf),labels=1:5))-1
#   K = length(unique(multinom_resp))
#   message("Fitting GSBART")
#   MGSB_Time = Sys.time()
#   MGSB_Fit = mgsbart2(multinom_resp, InputGraphs, 25, 15, nkeep = 1250,
#                       graphs_weight, hyperpar, modelpar, nthreads = 1, seed = 1234)
#   MGSB_Time = Sys.time() - MGSB_Time
#   MGSB_y_test = MGSB_Fit$yhat.test
#   MGSB_ACC = mean(MGSB_y_test == multinom_resp_test)
#   MGSB_CM = confusionMatrix(factor(MGSB_y_test, levels = (0:(K - 1))),
#                             factor(multinom_resp_test, levels = (0:(K - 1))))
#   sim.list[[i]] = data.frame(
#     models = c("GSBART"), ACC = c(MGSB_ACC),
#     times = c(MGSB_Time), sim = c(repetition)
#   )
# }

# save(sim.list, file = "~/Downloads/GSBart_rebuttal/Torus/GSBTorusmultdeep.Rdata")

# sim.summary = sim.list%>%
#   list_rbind() %>%
#   group_by(models) %>%
#   summarise(across(c('ACC', 'times'),
#                    list("mean" = mean, "sd" = sd),
#                    .names = "{.col}_{.fn}")) %>%
#   arrange(match(models, c("GSBART"), desc(models)))

# print(sim.summary)

# save(sim.list, sim.summary, file = "~/Downloads/GSBart_rebuttal/Torus/GSBTorusmultdeep.Rdata")

# library(testthat)
# library(purrr)
# library(dplyr)
# load('~/Downloads/code/test_code/testUshapecnt.Rdata')
# repetitions = 1
# n_rounds= 50
# sim.list = vector(mode = "list", length = repetitions)
# for(repetition in 1:repetitions){
#   set.seed(1234+repetition)
#   message("Sampling Y")
#   sim$Y0 = exp((sim$f_true+7)/3)
#   sim$Y0_ho = exp((sim$f_ho_true+7)/3)
#   sim$Y <- rpois(800, sim$Y0)
#   sim$Y_ho <- rpois(200, sim$Y0_ho)
#   hyperpar['b'] = 0.5*var(log(sim$Y+.01))/n_rounds;
#   nu = 3; q = 0.9;  quant = qchisq(1-q, nu)
#   hyperpar['lambda'] = (var(log(sim$Y+.01))*quant)/nu
#   hyperpar['mu0'] = mean(log(sim$Y+0.01))/n_rounds
#   GSBart_Time = Sys.time()
#   GSBres <- GenGSBart(sim$Y, 25, 15, 1250, InputGraphs, graphs_weight, hyperpar, modelpar, 2, 7, verbose = T, seed = 1234)
#   GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
#   GSBart_RMSE = sqrt(mean((sim$Y0_ho - exp(colMeans(GSBres$phi.test)))^2))
#   GSBart_MSE = mean((sim$Y0_ho - exp(colMeans(GSBres$phi.test)))^2)
#   sim.list[[repetition]] = data.frame(
#     models = c("GSBart"),
#     RMSE = c(GSBart_RMSE),
#     MSE = c(GSBart_MSE),
#     times = c(GSBart_Time),
#     sim = c(repetition)
#   )
# }

# load('~/Downloads/code/test_code/testToruscntorg.Rdata')
# n_train = nrow(sim$X); n_test = nrow(sim$X_ho)
# n_rounds = length(InputGraphs)
# repetitions = c(1:50)
# sim.list = vector(mode = "list", length = length(repetitions))

# for(i in 1:length(repetitions)){
#     repetition = repetitions[i]
#     set.seed(1234+repetition)
#     sim$Y0 = exp((sim$f_true+17)/8)
#     sim$Y0_ho = exp((sim$f_ho_true+17)/8)
#     sim$Y <- rpois(n_train, sim$Y0)
#     sim$Y_ho <- rpois(n_test, sim$Y0_ho)

#     hyperpar['tree_iter'] = 15; hyperpar['max_depth'] = 6
#     hyperpar['b'] = 0.5*var(log(sim$Y+.01))/n_rounds;
#     nu = 3; q = 0.9;  quant = qchisq(1-q, nu)
#     hyperpar['lambda'] = (var(log(sim$Y+.01))*quant)/nu
#     hyperpar['mu0'] = mean(log(sim$Y+0.01))/n_rounds

#     GSBart_Time = Sys.time()
#     GSBres <- GenGSBart(sim$Y , 25, 15, 1250, InputGraphs, graphs_weight,
#                         hyperpar, modelpar, 2, 7, verbose = F, seed = 1234)
#     GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
#     GSBart_RMSE = sqrt(mean((sim$Y0_ho - exp(colMeans(GSBres$phi.test)))^2))
#     GSBart_MSPE = mean((sim$Y0_ho - exp(colMeans(GSBres$phi.test)))^2)

#   sim.list[[i]] = data.frame(
#     models = c("GSBart"),
#     MSPE = c(GSBart_MSPE),
#     RMSE = c(GSBart_RMSE),
#     times = c(GSBart_Time),
#     sim = c(repetition)
#   )
#   message(paste("Iteration", repetition, "Done"))
#   message("RMSE:", GSBart_RMSE)
# }

# save(sim.list, file = "~/Downloads/GSBart_rebuttal/Torus/GSBToruscntorg.Rdata")

# sim.summary = sim.list%>%
#   list_rbind() %>%
#   group_by(models) %>%
#   summarise(across(c('MSPE', 'RMSE', 'times'),
#                    list("mean" = mean, "sd" = sd),
#                    .names = "{.col}_{.fn}")) %>%
#   arrange(match(models, c("GSBART"), desc(models)))

# print(sim.summary)

# save(sim.list, sim.summary, file = "~/Downloads/GSBart_rebuttal/Torus/GSBToruscntorg.Rdata")


# library(testthat)
# library(purrr)
# library(dplyr)
# library(bayestestR)
# load('~/Downloads/code/test_code/testPiecewisecnt.Rdata')
# hyperpar['tree_iter'] = 4; hyperpar['max_depth'] = 3;
# n_rounds = length(InputGraphs[1])
# hyperpar['b'] = 0.5*var(log(sim$Y+.01))/n_rounds;
# modelpar['tausq'] = (3/(2*sqrt(n_rounds)))^2

# GSBart_Time = Sys.time()
# GSBres <- GenGSBart(sim$Y, 750, 250, 750, InputGraphs[1], graphs_weight, hyperpar, modelpar, 2, 1, verbose = T, seed = 1234)
# GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
# GSBart_pred_unstandardized =  exp(colMeans(GSBres$phi.train))
# GSBart_MSPE = mean((Y0 - GSBart_pred_unstandardized)^2)
# GSBart_MAPE = mean(abs(GSBart_pred_unstandardized - Y0))
# print(GSBart_MSPE); print(GSBart_MAPE); 

# save(GSBres, GSBart_Time, GSBart_pred_unstandardized, file = "~/Downloads/GSBart_rebuttal/Pwcnt/GSBPwcntPoionetree.Rdata")


# library(testthat)
# library(purrr)
# library(dplyr)

# setwd('/Users/shurenhe/Downloads/code/GSBart_test/cora/')
# load('Cora.Rdata')
# load('coraGSBART.Rdata')
# load('Graphs.Rdata')

# InputGraphs = Graphs
# N = length(Y_train); pred_flag = T
# InputGraphs = lapply(InputGraphs, function(x) {
#   lapply(x, function(y) {
#     stopifnot(length(igraph::graph.attributes(y$g)$tr2mesh) == N,
#               length(unique(do.call(c, igraph::vertex.attributes(y$g)$mesh2tr))) == N)
#     if(pred_flag){
#       tmp = list(root = y$root,
#                   children = y$children,
#                   mesh2tr = igraph::vertex.attributes(y$g)$mesh2tr,
#                   mesh2ho = igraph::vertex.attributes(y$g)$mesh2ho,
#                   tr2mesh = igraph::graph.attributes(y$g)$tr2mesh,
#                   ho2mesh = igraph::graph.attributes(y$g)$ho2mesh)
#     }else{
#       tmp = list(root = y$root,
#                   children = y$children,
#                   mesh2tr = igraph::vertex.attributes(y$g)$mesh2tr,
#                   mesh2ho = vector(mode = 'list', length = length(igraph::vertex.attributes(y$g)$mesh2tr)), # place holder
#                   tr2mesh = igraph::graph.attributes(y$g)$tr2mesh,
#                   ho2mesh = c(1))
#     }
#     return(tmp)})
# })
# # Reduce every index by 1 to make everything 0 indexed
# InputGraphs = lapply(InputGraphs, function(x) {
#   lapply(x, function(y) {
#     list(root = y$root - 1,
#           children = unname(lapply(y$children, function(z){unname(z) - 1})),
#           mesh2tr = unname(lapply(y$mesh2tr, function(z){unname(z) - 1})),
#           mesh2ho = unname(lapply(y$mesh2ho, function(z){unname(z) - 1})),
#           tr2mesh = unname(y$tr2mesh - 1),
#           ho2mesh = unname(y$ho2mesh - 1))
#   })
# })

# graphs_weight = c(rep(0.15,5), rep(0.85/(length(Graphs[[1]])-5),(length(Graphs[[1]])-5)))
# hyperpar <- as.list(hyperpar_GSB)
# modelpar <- as.list(modelpar_GSB)
# hyperpar['iter_pre_tree'] <- NULL; hyperpar['prob_split_by_x'] <- NULL
# hyperpar['n_rounds'] <- NULL; hyperpar['n_chain'] <- NULL; hyperpar['split_eps'] <- 2
# hyperpar['tree_iter'] <- 12;
# modelpar['tausq'] <- modelpar['sigmasq_mu']; modelpar['sigmasq_mu']<- NULL

# Cora_Fit = mgsbart2(Y_train, InputGraphs, ndpost = 10, nskip = 5, nkeep = 1000, graphs_weight, hyperpar, 
#                     modelpar, nthreads = 7, dart = F, const_theta = T, seed = 1234)
# save(Cora_Fit, file = "/Users/shurenhe/Downloads/code/GSBart_test/cora/Cora_Fit.Rdata")
# MGSB_y_test = Cora_Fit$yhat.test
# MGSB_ACC = mean(MGSB_y_test == Y_test)
