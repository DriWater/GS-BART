#include "fitGSBart.h"

fitOutput fitGSBart(arma::vec Y, std::vector<std::vector<OST>> &inputGraphs, std::vector<double> lgw, const unsigned int ndpost,
                    const unsigned int nskip, const unsigned int nkeep, const unsigned int nthreads, const unsigned int tree_iter,
                    const unsigned int split_eps, const unsigned int max_depth, const double alpha, const double beta, const double rb,
                    const double nu, const double lambda, const double a, double b, const double eta, const double zeta, const double rho,
                    double sigmasq, double tausq, double theta, const bool dart, const bool const_theta, const bool verbose){
  DEBUG_MSG("Entered GSBart");
  #ifdef _OPENMP
  if(nthreads > 0) {
    omp_set_num_threads(nthreads);
  }
  else {
    omp_set_num_threads(1);
  }
  DEBUG_MSG("Max num OMP threads: " << nthreads);
#endif
  const unsigned int n = Y.n_elem;
  const unsigned int n_ho = inputGraphs[0][0].numTest();
  DEBUG_MSG("Read in Y, Y_ho");
  double tausq_init = tausq;
  double sigmasq_init = sigmasq;
  unsigned int n_graphs = inputGraphs[0].size();
  // turning all the values in Graphs into RootGraphs
  // Outer vector goes from 0 < n_rounds, inner vectors go from 0 < n_graphs
  unsigned int ntrees = inputGraphs.size(); arn gen;
  arma::vec phi(n, arma::fill::zeros);
  arma::vec phi_ho(n_ho, arma::fill::zeros);
  arma::mat mu_mat(n, ntrees, arma::fill::zeros);
  arma::mat mu_new_mat(n_ho, ntrees, arma::fill::zeros);
  // unsigned int nskip; bool keepdraw;
  std::vector<unsigned int> sample_iters;
  double step = static_cast<double>(ndpost) * ntrees / nkeep;
  for (unsigned int i = 1; i <= nkeep; ++i) {
      unsigned int sample_iter = std::round(i * step) - 1;
      // if (sample_iter > total_iterations) sample_iter = total_iterations;
      sample_iters.push_back(sample_iter);
  }
  // if(nkeep) {nskip = (ndpost*ntrees/nkeep>0) ? (ndpost*ntrees/nkeep) : 1;}
  // else{nskip = ndpost*ntrees + 1;}
  arma::vec sigmadraw((ndpost+nskip), arma::fill::zeros);
  arma::vec taudraw((ndpost+nskip), arma::fill::zeros);
  arma::mat trdraw(nkeep, n, arma::fill::zeros);
  arma::mat tedraw(nkeep, n_ho, arma::fill::zeros);
  arma::uvec train_cids(n, arma::fill::zeros);
  arma::uvec test_cids(n_ho, arma::fill::zeros);
  std::vector<tree> Ptree_lst(ntrees); bool dartOn = false;
  arma::umat varcnt(ndpost, n_graphs, arma::fill::zeros);
  std::vector<double> mu_vec; std::vector<unsigned int> vcnt(n_graphs, 0);
  unsigned int drawcnt = 0; std::stringstream treess;  //string stream to write trees to
  treess.precision(10); treess << nkeep << " " << ntrees << " " << n_graphs << endl;
  for(unsigned int round = 0; round < (ndpost + nskip); round++){
    if(round == 1){
      tausq = tausq_init; sigmasq = sigmasq_init;
    }
    if(round >= nskip/2){if(dart){dartOn = true;}}
    for(unsigned int m = 0; m < ntrees; m++) {
      bool keepdraw = false;
      if((sample_iters.size() > 0) && (round >(nskip-1))){
        if(sample_iters[0] == (round - nskip)*ntrees + m){
          keepdraw = true; sample_iters.erase(sample_iters.begin());
        }
      }
      // keepdraw = (unsigned int) nkeep && ((((round - nskip)*ntrees + m + 1) % nskip)==0) && (round >(nskip-1));
      if(round == 0){
        tausq = tausq_init * std::pow((double) ntrees, 2.0);
        sigmasq = sigmasq_init;
      }
      DEBUG_MSG("Calculating gradients_i");
      arma::vec muhat = mu_mat.col(m); arma::vec muhat_ho = mu_new_mat.col(m);
      phi -= muhat; phi_ho -= muhat_ho;
      arma::vec em = Y - phi;
      ProposeMove(inputGraphs[m], em, train_cids, test_cids, Ptree_lst[m], lgw, tree_iter,
                  max_depth, sigmasq, tausq, alpha, beta, split_eps, rb, gen);
      drmu(Ptree_lst[m], em, muhat, muhat_ho, train_cids, test_cids, mu_vec, sigmasq, tausq, gen);
      phi_ho += muhat_ho; phi += muhat;
      drsigmasq(Y, phi, sigmasq, nu, lambda, gen);
      train_cids.fill(0); test_cids.fill(0);
      if(round == 0){
        phi.fill(0); phi_ho.fill(0);
        muhat /= (double) ntrees; muhat_ho /= (double) ntrees;
      }
      mu_mat.col(m) = muhat; mu_new_mat.col(m) = muhat_ho;
      if(keepdraw){
        trdraw.row(drawcnt)=arma::conv_to<arma::rowvec>::from(phi);
        tedraw.row(drawcnt)=arma::conv_to<arma::rowvec>::from(phi_ho);
        drawcnt ++;
      }
    }
    if(round == 0){
      std::transform(mu_vec.begin(), mu_vec.end(), mu_vec.begin(),
                    [ntrees](double x) { return x / (double) ntrees; });
      phi = arma::sum(mu_mat, 1);
      phi_ho = arma::sum(mu_new_mat, 1);
    }
    drtausq(mu_vec, tausq, a, b, gen);
    // b = 0.5 * arma::var(phi)/((double) ntrees);
    taudraw[round] = std::sqrt(tausq);
    sigmadraw[round] = std::sqrt(sigmasq);
    // unsigned int tot_node_size = 0;
    for(unsigned int m = 0; m < ntrees; ++m){ Ptree_lst[m].varcount(vcnt); }
    if(dartOn){
      draw_s(vcnt, lgw, theta, gen);
      // std::vector<double> exp_vals(7);
      // std::transform(lgw.begin(), lgw.begin() + 7, exp_vals.begin(), [](double x) {
      //     return std::exp(x);
      // });
      // double mean = std::accumulate(exp_vals.begin(), exp_vals.end(), 0.0) / 5.0;
      // double log_mean = std::log(mean);
      // std::fill(lgw.begin(), lgw.begin() + 7, log_mean);
      draw_theta0(const_theta, theta, lgw, eta, zeta, rho, gen);
    }
    if(verbose){
      printf("*****Iteration %u done\n", (round+1));
      printf("*****Number of splits for each graph\n");
      Rcpp::Rcout << arma::conv_to<arma::urowvec>::from(vcnt) << std::endl;
      if(dartOn){
        if(!const_theta){printf("*****The value of theta is %.3f\n", theta);}
        printf("*****The probability of selecting each graph\n");
        Rcpp::Rcout << std::fixed << std::setprecision(4) << arma::exp(arma::rowvec(lgw)) << std::endl;
      }
    }
    if(round>=nskip){
      varcnt.row(round - nskip)=arma::conv_to<arma::urowvec>::from(vcnt);
      for(unsigned int m = 0; m < ntrees; ++m){ treess << Ptree_lst[m]; }
    }
    std::fill(vcnt.begin(), vcnt.end(), 0); mu_vec.clear();
    // Rcpp::Rcout << "Start free tree" << std::endl;
    for(unsigned int m = 0; m < ntrees; ++m){Ptree_lst[m].tonull();}
  }
  fitOutput ret = {
    /*.trdraw =*/ trdraw,
    /*.tedraw =*/ tedraw,
    /*.varcnt =*/ varcnt,
    /*.sigmadraw =*/ sigmadraw,
    /*.taudraw =*/ taudraw,
    /*.treelist =*/ treess.str()
  };
  return(ret);
}

