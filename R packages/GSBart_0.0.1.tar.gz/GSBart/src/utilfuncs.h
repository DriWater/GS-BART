#pragma once
#include <vector>
#include <utility>
#include <iterator>
// Why don't you come on over valarray?
#include <valarray>
#include <set>
#include <ostream>
#include <stdexcept>
#include <algorithm>
#include <unordered_map>
#include <cstddef>
#include <cmath>
#include <stdexcept>
#include <limits>

#include "GraphInfo.h"
#include "OST.h"
#include "Gradients.h"
#include "tree.h"
#include "rn.h"
#include "debug_msg.h"
#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

#ifdef _OPENMP
#include <omp.h>
#endif
// [[Rcpp::plugins(openmp)]]


// Utility functions

GraphInfo infoPass(OST &graph, const Gradients &gradients, const unsigned int v,
                   const unsigned int nc, const unsigned int n);
                   
void ProposeMove(std::vector<OST> &graphs, const arma::vec &em, arma::uvec &train_cids, arma::uvec &test_cids,
                 tree &Ptree, std::vector<double> &log_graphs_weight, const unsigned int &tree_iter, 
                 const unsigned int &max_depth, const double &sigmasq, const double &tausq, const double &alpha, 
                 const double &beta, const unsigned int &split_eps, const double &rb, rn& gen);

void drmu(tree& Ptree, const arma::vec &em, arma::vec &muhat, arma::vec &muhat_ho, const arma::uvec &train_cids, 
          const arma::uvec &test_cids, std::vector<double> &mu_vec, const double &sigmasq, const double &tausq,
          rn& gen);
// draw tausq
void drtausq(const std::vector<double> &mu_vec, double &tausq, const double &a, const double &b, rn& gen);

//draw sigmasq
void drsigmasq(const arma::vec &Y, const arma::vec &phi, double &sigmasq, const double &nu, const double &lambda, rn& gen);

void draw_s(std::vector<unsigned int>& nv, std::vector<double>& lpv, double& theta, rn& gen);

void draw_theta0(bool const_theta, double& theta, std::vector<double>& lpv, double eta, double zeta, double rho, rn& gen);
