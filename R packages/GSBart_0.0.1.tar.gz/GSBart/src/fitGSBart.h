#pragma once
// #define GSBART_DEBUG
#include <vector>
#include <utility>
#include <iterator>
#include <valarray>
#include <set>
#include <ostream>
#include <stdexcept>
#include <algorithm>

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]
#include <RcppArmadillo.h>

#ifdef _OPENMP
#include <omp.h>
#endif
// [[Rcpp::plugins(openmp)]]

#include "utilfuncs.h"
#include "debug_msg.h"

typedef struct {
  arma::mat trdraw;
  arma::mat tedraw;
  arma::umat varcnt; 
  arma::vec sigmadraw;
  arma::vec taudraw;
  // arma::umat treedepth; 
  std::string treelist;
} fitOutput;

fitOutput fitGSBart(arma::vec Y, std::vector<std::vector<OST>> &inputGraphs, std::vector<double> log_graphs_weight,
                    const unsigned int ndpost, const unsigned int nskip, const unsigned int nkeep, const unsigned int nthreads, 
                    const unsigned int tree_iter, const unsigned int split_eps, const unsigned int max_depth, const double alpha,
                    const double beta, const double rb, const double nu, const double lambda, const double a, double b, 
                    const double eta, const double zeta, const double rho, double sigmasq, double tausq, double theta,
                    const bool dart, const bool const_theta, const bool verbose);
