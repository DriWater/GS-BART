#include "aggregator.h"


template<typename T, typename G>
std::pair<std::vector<std::vector<T>>, std::vector<std::vector<G>>> groupBy(
    const std::vector<std::vector<T>>& toReduce,
    const std::vector<std::vector<G>>& groups,
    std::function<T(T, T)> reduceFunc) {
  const size_t numRows = toReduce[0].size();
  // const size_t numCols = toReduce.size() + groups.size();
  GroupByMap<T, G> groupByMap;
  
  for (std::size_t i = 0; i < numRows; i++) {
    std::vector<G> key;
    for (const auto& group : groups) {
      key.push_back(group[i]);
    }
    auto& values = groupByMap[key];
    if (values.empty()) {
      values.resize(toReduce.size());
    }
    for (std::size_t j = 0; j < toReduce.size(); j++) {
      values[j] = reduceFunc(values[j], toReduce[j][i]);
    }
  }
  
  std::vector<std::vector<T>> reduced(toReduce.size());
  std::vector<std::vector<G>> grouped(groups.size());
  //reduced.reserve(toReduce.size());
  //grouped.reserve(groups.size());
  
  // The below is syntactic sugar that unfortunately doesn't work with clang
  
  // for (const auto& [key, values] : groupByMap) {
  //   for (std::size_t j = 0; j < toReduce.size(); j++) {
  //     reduced[j].push_back(values[j]);
  //   }
  //   for (std::size_t k = 0; k < groups.size(); k++) {
  //     grouped[k].push_back(key[k]);
  //   }
  // }
  
  for (auto& entry : groupByMap) {
    for (std::size_t j = 0; j < toReduce.size(); j++) {
      reduced[j].push_back(entry.second[j]);
    }
    for (std::size_t k = 0; k < groups.size(); k++) {
      grouped[k].push_back(entry.first[k]);
    }
  }
  
  return std::make_pair(reduced, grouped);
}


std::pair<arma::mat, 
          arma::umat> groupBy(const arma::mat& toReduce, 
                              const arma::umat& groups, 
                              std::function<arma::rowvec(arma::rowvec, 
                                                         arma::rowvec)> reduceFunc){
  const std::size_t numRows = toReduce.n_rows;
  const std::size_t numReduceCols = toReduce.n_cols;
  const std::size_t numGroupCols = groups.n_cols;
  std::unordered_map<arma::urowvec, arma::rowvec, ArmaHasher, ArmaKeyEqual> groupByMap;
  
  for (std::size_t i = 0; i < numRows; i++) {
    arma::urowvec key = groups.row(i);
    auto& values = groupByMap[key];
    if (values.empty()) {
      values.zeros(numReduceCols);
    }
    values = reduceFunc(values, toReduce.row(i));
  }
  const size_t numReturn = groupByMap.size();
  
  arma::mat reduced(numReturn, numReduceCols, arma::fill::zeros);
  arma::umat grouped(numReturn, numGroupCols, arma::fill::zeros);
  
  std::size_t i = 0;
  for (auto& entry : groupByMap) {
    reduced.row(i) = entry.second;
    grouped.row(i) = entry.first;
    ++i;
  }
  
  return std::make_pair(reduced, grouped);
}


std::pair<arma::mat, 
          arma::umat> groupBy(const arma::mat& toReduce, 
                              const arma::umat& groups){
  const std::size_t numRows = toReduce.n_rows;
  const std::size_t numReduceCols = toReduce.n_cols;
  const std::size_t numGroupCols = groups.n_cols;
  std::unordered_map<arma::urowvec, arma::rowvec, ArmaHasher, ArmaKeyEqual> groupByMap;
  
  for (std::size_t i = 0; i < numRows; i++) {
    arma::urowvec key = groups.row(i);
    auto& values = groupByMap[key];
    if (values.empty()) {
      values.zeros(numReduceCols);
    }
    values += toReduce.row(i);
  }
  const size_t numReturn = groupByMap.size();
  
  arma::mat reduced(numReturn, numReduceCols, arma::fill::zeros);
  arma::umat grouped(numReturn, numGroupCols, arma::fill::zeros);
  
  std::size_t i = 0;
  for (auto& entry : groupByMap) {
    reduced.row(i) = entry.second;
    grouped.row(i) = entry.first;
    ++i;
  }
  
  return std::make_pair(reduced, grouped);
}
