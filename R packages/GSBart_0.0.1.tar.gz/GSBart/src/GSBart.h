#pragma once
#include "fitGSBart.h"

Rcpp::List GSBart(Rcpp::NumericVector Y_train,
                    const unsigned int ndpost,
                    const unsigned int nskip,
                    const unsigned int nkeep,
                    Rcpp::List Graphs,
                    Rcpp::NumericVector graphs_weight,
                    Rcpp::List Hyperpars,
                    Rcpp::List Modelpars,
                    const unsigned int nthreads,
                    const bool pred_flag,
                    const bool dart, 
                    const bool const_theta,
                    const bool verbose, int seed);

std::vector<std::vector<unsigned int>> adj_list_from_R_list(const Rcpp::List &adj_list);

void set_rng_seed(int seed);
