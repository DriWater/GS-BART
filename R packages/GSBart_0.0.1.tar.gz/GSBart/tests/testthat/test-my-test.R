# library(testthat)
# load('~/Downloads/code/test_code/testUshapedata.Rdata')
# hyperpar['tree_iter'] = 10
# hyperpar['split_eps'] = 0
# tmp <- GenGSBart(sim$Y, 25, 15, 2000, InputGraphs, graphs_weight, hyperpar, modelpar, 0, 6, verbose = T, seed = 123)
# print(tmp$sigma); print(tmp$tau)
# # print(tmp$tree.draws)
# print(table(as.vector(tmp$tree.depth)))
# print(mean((sim$Y_ho - colMeans(tmp$phi.test))^2))
# print(mean((sim$Y - colMeans(tmp$phi.train))^2))
# print("Train data mse")
# print(colMeans((sim$Y - t(tmp$phi.train))^2))
# print("Test data mse")
# print(colMeans((sim$Y_ho - t(tmp$phi.test))^2))


# library(testthat)
# load('~/Downloads/code/test_code/testUshapecnt.Rdata')
# tmp <- GenGSBart(sim$Y, 25, 15, 625, InputGraphs, graphs_weight, hyperpar, modelpar, 2, 6, verbose = T, seed = 1234)
# print(sqrt(mean((sim$Y0_ho - exp(colMeans(tmp$phi.test*tmp$weight)/sum(tmp$weight)))^2)))
# print(sqrt(mean((exp(tmp$phi.test) - sim$Y0_ho)^2)))
# print(tmp$sigma); print(tmp$tau)
# print(table(as.vector(tmp$tree.depth)))
# # print(tmp$tree.draws)
# print("Train data mse")
# print(colMeans((sim$Y - t(tmp$phi.train))^2))
# print("Test data mse) 
# print(colMeans((sim$Y_ho - t(tmp$phi.test))^2))


# library(testthat)
# load('~/Downloads/code/test_code/whitenoisecntdata.Rdata')
# hyperpar['max_depth'] = 9
# hyperpar['alpha'] = 0.95
# hyperpar['beta'] = 2
# hyperpar['tree_iter'] = 16

# tmp <- GenGSBart(y_cnt, 15, 25, 15, InputGraphs, graphs_weight, hyperpar, modelpar, 2, 6, verbose = T)
# # print(mean((sim$Y_ho - colMeans(tmp$phi.test))^2))
# print(tmp$sigma)
# print(tmp$tau)
# print(tmp$tree.draws)


# library(testthat)
# library(ggplot2)
# load('~/Downloads/code/test_code/KingHouse.Rdata')
# set.seed(1234)
# subInputGraphs = vector(mode = "list", length = length(InputGraphs))
# Graph_len = length(InputGraphs[[1]])
# for( i in 1:length(InputGraphs)){
#   graphs_id = sample(1:Graph_len, 18, prob = graphs_weight)
#   graphs_id = graphs_id[order(graphs_id)]
#   subInputGraphs[[i]] = InputGraphs[[i]][graphs_id]
# }
# hyperpar['mu0'] = NULL
# hyperpar['rb'] = 0.9; 
# hyperpar['alpha'] = .95
# hyperpar['beta'] = 2
# hyperpar['split_eps'] = 0
# hyperpar['tree_iter'] = 12
# hyperpar['b'] = 0.5*var(Y)/100
# hyperpar['nu'] = 2
# hyperpar['eta'] = .5
# hyperpar['zeta'] = 1
# hyperpar['split_eps'] = 0
# modelpar['theta'] = 0.1
# hyperpar['rho'] = length(InputGraphs[[1]])
# Unstandardize = function(x, std_par){ return(x * std_par['scale'] + std_par['mean']) }
# GSBart_Time = Sys.time()
# KingHouseres <- GSBart(Y, 10, 2, 2000, InputGraphs, graphs_weight, hyperpar, modelpar,
#                        9, dart = T, const_theta = F, verbose = T, seed = 1234)
# save(KingHouseres, file = "~/Downloads/GSBart_rebuttal/KingHouse/KingHouseGSBsparse.Rdata")
# GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
# GSB.pred.unstandardized = Unstandardize(colMeans(KingHouseres$phi.test), stdY$std_par)
# GSBart_MSPE = mean((GSB.pred.unstandardized - y.test.unstandardized)^2)
# GSBART_MAPE = mean(abs(GSB.pred.unstandardized - y.test.unstandardized))
# print(GSBart_MSPE); print(GSBART_MAPE);  print(GSBart_Time)

# library(testthat)
# library(ggplot2)
# load('~/Downloads/code/test_code/Election.Rdata')
# hyperpar['rb'] = 0.9; 
# hyperpar['alpha'] = .95
# hyperpar['tree_iter'] = 12
# hyperpar['beta'] = 2
# hyperpar['split_eps'] = 0
# hyperpar['b'] = 0.5*var(Y)/50
# modelpar['tausq'] = (0.5/(2*sqrt(50)))^2
# Unstandardize = function(x, std_par){ return(x * std_par['scale'] + std_par['mean']) }
# Electionres <- GenGSBart(Y, 25, 15, 2000, InputGraphs, graphs_weight, hyperpar, modelpar, 7, verbose = T, seed = 1234)
# save(Electionres, file = "~/Downloads/GSBart_rebuttal/Election/Electionres.Rdata")
# GSB.pred.unstandardized = Unstandardize(colMeans(GSB_res$phi.test), stdY$std_par)
# GSBart_MSPE = mean((GSB.pred.unstandardized - y.test.unstandardized)^2)
# GSBart_MAPE = mean(abs(GSB.pred.unstandardized - y.test.unstandardized))
# print(GSBart_MSPE); print(GSBart_MAPE); 
# print(GSB_res$sigma); print(GSB_res$tau)
# print("Train data mse")
# print(colMeans((Y - t(GSB_res$phi.train))^2))
# print("Test data mse")
# print(colMeans((Y_ho - t(GSB_res$phi.test))^2))
# # print(tmp$tree.draws)
# print(table(as.vector(GSB_res$tree.depth)))


# library(testthat)
# library(purrr)
# library(dplyr)
# library(bayestestR)
# load('~/Downloads/code/test_code/testUshapeReg.Rdata')

# set.seed(1234)
# subInputGraphs = vector(mode = "list", length = length(InputGraphs))
# Graph_len = length(InputGraphs[[1]])
# for( i in 1:length(InputGraphs)){
#   graphs_id = sample(1:Graph_len, 12, prob = graphs_weight)
#   graphs_id = graphs_id[order(graphs_id)]
#   subInputGraphs[[i]] = InputGraphs[[1]][graphs_id]
# }

# hyperpar['mu0'] = NULL

# repetitions = c(6); 
# n_rounds= 50
# sigmasq_y = 0.15 # Ushape
# modelpar['tausq'] = (0.5/(2*sqrt(n_rounds)))^2
# nu = 3; q = 0.9; quant = qchisq(1-q, nu)
# n = nrow(sim$X); n_ho = nrow(sim$X_ho)
# hyperpar['tree_iter'] = 15; hyperpar['max_depth'] = 6

# Standardize = function(Y, std_par = NULL) {
#   if(is.null(std_par)) {
#     ymean = mean(Y)
#     yscale = 2 * max(abs(Y))
#   } else {
#     ymean = std_par['mean']
#     yscale = std_par['scale']
#   }
#   Y = (Y - ymean) / yscale
#   std_par = c('mean' = ymean, 'scale' = yscale)
#   return(list(Y = Y, std_par = std_par))
# }


# Unstandardize = function(x, std_par) {
#   return(x * std_par['scale'] + std_par['mean']) 
# } 

# sim.list = vector(mode = "list", length = length(repetitions))

# for(repetition in repetitions){
#   set.seed(1234+repetition)
#   message("Sampling Y")
#   Y0 = sim$f_true + rnorm(n, 0, sigmasq_y)
#   Y0_ho = sim$f_ho_true + rnorm(n_ho, 0, sigmasq_y)
#   ## standardize data
#   stdY = Standardize(Y0)
#   sim$Y = stdY$Y
#   sim$Y_ho = (Y0_ho - stdY$std_par['mean']) / stdY$std_par['scale']
#   hyperpar['b'] = 0.5*var(sim$Y)/n_rounds;
#   hyperpar['lambda'] = (var(sim$Y)*quant)/nu;
#   modelpar['sigmasq'] = var(sim$Y)
#   GSBart_Time = Sys.time() # seed 1145 1236
#   GSBres <- GenGSBart(sim$Y, 25, 15, 1250, subInputGraphs, graphs_weight, hyperpar, modelpar, 7, verbose = F, seed = 1234)
#   GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
#   GSBart_Y_out = t(apply(GSBres$phi.test, 1, function(X){Unstandardize(X, stdY$std_par)}))
#   GSBart_pred_unstandardized = colMeans(GSBart_Y_out)
#   GSBart_MSPE = mean((Y0_ho - GSBart_pred_unstandardized)^2)
#   GSBart_MAPE = mean(abs(GSBart_pred_unstandardized - Y0_ho))
#   GSBart_MSE_std = GSBart_MSPE/mean(sim$Y)
#   GSBart.upper.lvl = NULL
#   GSBart.lower.lvl = NULL
#   for(i in 1:ncol(GSBart_Y_out)){
#     tmp <- ci(GSBart_Y_out[,i], method = "HDI")
#     GSBart.upper.lvl <- append(GSBart.upper.lvl, tmp$CI_high)
#     GSBart.lower.lvl <- append(GSBart.lower.lvl, tmp$CI_low)
#   }
#   GSBart_coverage = mean((Y0_ho<GSBart.upper.lvl)&(Y0_ho>GSBart.lower.lvl))
#   GSBart_HDI_len = mean(GSBart.upper.lvl - GSBart.lower.lvl)
#   GSBart_poster_sd = mean(apply(GSBart_Y_out, 2, sd))

#   sim.list[[repetition]] = data.frame(
#     models = c("GSBart"),
#     MSPE = c(GSBart_MSPE),
#     MAPE = c(GSBart_MAPE),
#     MSPE_std = c(GSBart_MSE_std), 
#     times = c(GSBart_Time),  
#     HDI_coverage = c(GSBart_coverage),
#     HDI_len = c(GSBart_HDI_len),
#     poster_sd = c(GSBart_poster_sd),
#     sim = c(repetition)
#   )
# }

# save(sim.list, file = "~/Downloads/GSBart_rebuttal/Ushape/GSBUshapereg.Rdata")

# sim.summary = sim.list%>%
#   list_rbind() %>%
#   group_by(models) %>%
#   summarise(across(c('MSPE', 'MAPE', 'MSPE_std', 'times', 'HDI_coverage', 'HDI_len', 'poster_sd'),
#                    list("mean" = mean, "sd" = sd),
#                    .names = "{.col}_{.fn}")) %>%
#   arrange(match(models, c("GSBART"), desc(models)))

# print(sim.summary)

# save(sim.list, sim.summary, file = "~/Downloads/GSBart_rebuttal/Ushape/GSBUshapereg.Rdata")

# library(testthat)
# library(purrr)
# library(dplyr)
# load('~/Downloads/code/test_code/testToruscntorg.Rdata')
# repetitions = c(1:50)
# n_rounds= 50
# sigmasq_y = 0.1 # Ushape
# hyperpar['mu0'] = 0; modelpar['tausq'] = (0.5/(2*sqrt(n_rounds)))^2
# nu = 3; q = 0.9; quant = qchisq(1-q, nu)
# n = nrow(sim$X); n_ho = nrow(sim$X_ho)
# hyperpar['tree_iter'] = 12; hyperpar['max_depth'] = 6; 
# hyperpar['nu'] = 3

# Standardize = function(Y, std_par = NULL) {
#   if(is.null(std_par)) {
#     ymean = mean(Y)
#     yscale = 2 * max(abs(Y))
#   } else {
#     ymean = std_par['mean']
#     yscale = std_par['scale']
#   }
#   Y = (Y - ymean) / yscale
#   std_par = c('mean' = ymean, 'scale' = yscale)
#   return(list(Y = Y, std_par = std_par))
# }


# Unstandardize = function(x, std_par) {
#   return(x * std_par['scale'] + std_par['mean']) 
# } 


# sim.list = vector(mode = "list", length = length(repetitions))
# for(i in 1:length(repetitions)){
#   repetition = repetitions[i]
#   set.seed(1234+repetition)
#   message("Sampling Y")
#   Y0 = sim$f_true + rnorm(n, 0, sigmasq_y)
#   Y0_ho = sim$f_ho_true + rnorm(n_ho, 0, sigmasq_y)
#   ## standardize data
#   stdY = Standardize(Y0)
#   sim$Y = stdY$Y
#   sim$Y_ho = (Y0_ho - stdY$std_par['mean']) / stdY$std_par['scale']
#   hyperpar['b'] = 0.5*var(sim$Y)/n_rounds;
#   hyperpar['lambda'] = (var(sim$Y)*quant)/nu;
#   modelpar['sigmasq'] = var(sim$Y)
#   GSBart_Time = Sys.time()
#   GSBres <- GenGSBart(sim$Y, 25, 15, 1250, InputGraphs, graphs_weight, hyperpar, modelpar, 0, 7, verbose = F, seed = 1234)
#   GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
#   GSBart_pred_unstandardized = Unstandardize(colMeans(GSBres$phi.test), stdY$std_par)
#   GSBart_MSPE = mean((Y0_ho - GSBart_pred_unstandardized)^2)
#   GSBart_MAPE = mean(abs(GSBart_pred_unstandardized - Y0_ho))


#   GSBart.upper.lvl = NULL
#   GSBart.lower.lvl = NULL
#   for(i in 1:ncol(GSBart_Y_out)){
#     tmp <- ci(GSBart_Y_out[,i], method = "HDI")
#     GSBart.upper.lvl <- append(GSBart.upper.lvl, tmp$CI_high)
#     GSBart.lower.lvl <- append(GSBart.lower.lvl, tmp$CI_low)
#   }
#   GSBart_coverage = mean((Y0_ho<GSBart.upper.lvl)&(Y0_ho>GSBart.lower.lvl))
#   GSBart_HDI_len = mean(GSBart.upper.lvl - GSBart.lower.lvl)
#   GSBart_poster_sd = mean(apply(GSBart_Y_out, 2, sd))


#   sim.list[[i]] = data.frame(
#     models = c("GSBart"),
#     MSPE = c(GSBart_MSPE),
#     MAPE = c(GSBart_MAPE),
#     times = c(GSBart_Time),
#     sim = c(repetition)
#   )
# }

# save(sim.list, file = "~/Downloads/GSBart_rebuttal/Torus/GSBTorusorgReg.Rdata")

# sim.summary = sim.list%>%
#   list_rbind() %>%
#   group_by(models) %>%
#   summarise(across(c('MSPE', 'MAPE', 'times'),
#                    list("mean" = mean, "sd" = sd),
#                    .names = "{.col}_{.fn}")) %>%
#   arrange(match(models, c("GSBART"), desc(models)))

# print(sim.summary)

# save(sim.list, sim.summary, file = "~/Downloads/GSBart_rebuttal/Torus/GSBTorusorgReg.Rdata")


# library(testthat)
# load('~/Downloads/code/test_code/NYEducation.Rdata')
# hyperpar['rb'] = 0.9; hyperpar['alpha'] = .95
# hyperpar['tree_iter'] = 12; hyperpar['max_depth'] = 6; 
# hyperpar['beta'] = 2
# hyperpar['split_eps'] = 0; hyperpar['b'] = 0.5*var(Y)/50
# modelpar['tausq'] = (0.5/(2*sqrt(50)))^2; modelpar['sigmasq'] = var(Y)
# Unstandardize = function(x, std_par){ return(x * std_par['scale'] + std_par['mean']) }
# GSBart_Time = Sys.time()
# NYUEdures <- GenGSBart(Y, 25, 15, 1250, InputGraphs, graphs_weight, hyperpar, modelpar, 7, verbose = T, seed = 1234)
# GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
# save(NYUEdures, file = "~/Downloads/GSBart_rebuttal/NYUEducation/NYUEdures.Rdata")
# GSB.pred.unstandardized = Unstandardize(colMeans(NYUEdures$phi.test), stdY$std_par)
# GSBart_MSPE = mean((GSB.pred.unstandardized - y.test.unstandardized)^2)
# GSBart_MAPE = mean(abs(GSB.pred.unstandardized - y.test.unstandardized))
# print(GSBart_MSPE); print(GSBart_MAPE); print(GSBart_Time)

# library(testthat)
# library(purrr)
# library(dplyr)
# library(bayestestR)
# library(sns)
# load('~/Downloads/code/test_code/testFriedmanReg.Rdata')
# repetitions = c(7)
# n_rounds= 50
# sigmasq_y = 1 # Ushape
# nu = 3; q = 0.9; quant = qchisq(1-q, nu)
# hyperpar['tree_iter'] = 12; hyperpar['max_depth'] = 6; 
# hyperpar['nu'] = 3
# hyperpar['eta'] = .5
# hyperpar['zeta'] = 1
# hyperpar['split_eps'] = 0
# modelpar['theta'] = 0.1
# hyperpar['rho'] = length(InputGraphs[[1]])

# for(i in 1:length(InputGraphs)){
#   for(j in 1:length(InputGraphs[[i]])){
#     InputGraphs[[i]][[j]]$mesh2tr <- InputGraphs[[i]][[j]]$mesh2trList
#     InputGraphs[[i]][[j]]$mesh2ho <- InputGraphs[[i]][[j]]$mesh2hoList
#     # InputGraphs[[i]][[j]]$mesh2ho <- NULL
#     InputGraphs[[i]][[j]]$mesh2trList <- NULL
#     InputGraphs[[i]][[j]]$mesh2hoList <- NULL
#     InputGraphs[[i]][[j]]$ho2mesh <- NULL
#   }
# }

# Standardize = function(Y, std_par = NULL) {
#   if(is.null(std_par)) {
#     ymean = mean(Y)
#     yscale = 2 * max(abs(Y))
#   } else {
#     ymean = std_par['mean']
#     yscale = std_par['scale']
#   }
#   Y = (Y - ymean) / yscale
#   std_par = c('mean' = ymean, 'scale' = yscale)
#   return(list(Y = Y, std_par = std_par))
# }


# Unstandardize = function(x, std_par) {
#   return(x * std_par['scale'] + std_par['mean']) 
# } 

# n = length(Ey); n_train = nrow(X); n_test = nrow(X_ho)

# sim.list = vector(mode = "list", length = length(repetitions))

# for(k in 1:length(repetitions)){
#   repetition = repetitions[k]
#   set.seed(1234+repetition)
#   message("Sampling Y")
#   y <- rnorm(n, Ey, sigmasq_y)
#   Y0=y[in_train]; Y0_ho=y[-in_train]
  
#   ## standardize data
#   stdY = Standardize(Y0)
#   Y = stdY$Y
#   Y_ho = (Y0_ho - stdY$std_par['mean']) / stdY$std_par['scale']
  
#   m = ncol(X)
#   if(m < n_train) {
#     df = data.frame(X ,Y)
#     lmf = lm(Y~.,df)
#     sigest = summary(lmf)$sigma
#   } else {
#     sigest = sd(Y)
#   }
  
#   hyperpar['lambda'] = (sigest*sigest*quant)/nu
#   hyperpar['b'] = 0.5*sigest*sigest/n_rounds
#   modelpar['sigmasq']=sigest*sigest 

#   GSBart_Time = Sys.time()
#   GSBres <- GSBart(Y, 20, 4, 20, InputGraphs, graphs_weight, hyperpar, modelpar, 5,
#                    pred_flag = F, dart = F, const_theta = T, verbose = T, seed = 1234)
#   GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
#   GSBart_Y_out = t(apply(GSBres$phi.test, 1, function(X){Unstandardize(X, stdY$std_par)}))
#   print(dim(GSBart_Y_out))
#   GSBart_pred_unstandardized = colMeans(GSBart_Y_out)
#   GSBart_MSPE = mean((Y0_ho - GSBart_pred_unstandardized)^2)
#   GSBart_MAPE = mean(abs(GSBart_pred_unstandardized - Y0_ho))
#   print(mean(ess(GSBart_Y_out, "coda")))

  # save(GSBres, GSBart_Y_out , GSBart_pred_unstandardized, Y0, Y0_ho, file = "~/Downloads/GSBart_rebuttal/Friedman/GSBres33.Rdata")

#   GSBart.upper.lvl = NULL
#   GSBart.lower.lvl = NULL
#   for(i in 1:ncol(GSBart_Y_out)){
#     tmp <- ci(GSBart_Y_out[,i], method = "HDI")
#     GSBart.upper.lvl <- append(GSBart.upper.lvl, tmp$CI_high)
#     GSBart.lower.lvl <- append(GSBart.lower.lvl, tmp$CI_low)
#   }
#   GSBart_coverage = mean((Y0_ho<GSBart.upper.lvl)&(Y0_ho>GSBart.lower.lvl))
#   GSBart_HDI_len = mean(GSBart.upper.lvl - GSBart.lower.lvl)
#   GSBart_poster_sd = mean(apply(GSBart_Y_out, 2, sd))

#   sim.list[[k]] = data.frame(
#     models = c("GSBart"),
#     MSPE = c(GSBart_MSPE),
#     MAPE = c(GSBart_MAPE),
#     HDI_coverage = c(GSBart_coverage),
#     HDI_len = c(GSBart_HDI_len),
#     poster_sd = c(GSBart_poster_sd),
#     times = c(GSBart_Time),
#     sim = c(repetition)
#   )
# }

# save(sim.list, file = "~/Downloads/GSBart_rebuttal/Friedman/GSBFriedmanReg100.Rdata")


# sim.summary = sim.list %>%
#   list_rbind() %>%
#   na.omit() %>%
#   group_by(models) %>%
#   # summarise(across(c('MSPE', 'MAPE', 'HDI_coverage', 'HDI_len', 'poster_sd', 'times'),
#   summarise(across(c('MSPE', 'MAPE', 'poster_sd', 'times'),
#                    list("mean" = mean, "sd" = sd),
#                    .names = "{.col}_{.fn}")) %>%
#   arrange(match(models, c("GSBart"), desc(models)))

# print(sim.summary)

# save(sim.list, sim.summary, file = "~/Downloads/GSBart_rebuttal/Friedman/GSBFriedmanReg100.Rdata")


# library(testthat)
# library(purrr)
# library(dplyr)
# library(bayestestR)
# load('~/Downloads/code/test_code/testPiecewiseReg.Rdata')

# Standardize = function(Y, std_par = NULL) {
#   if(is.null(std_par)) {
#     ymean = mean(Y)
#     yscale = 2 * max(abs(Y))
#   } else {
#     ymean = std_par['mean']
#     yscale = std_par['scale']
#   }
#   Y = (Y - ymean) / yscale
#   std_par = c('mean' = ymean, 'scale' = yscale)
#   return(list(Y = Y, std_par = std_par))
# }

# Unstandardize = function(x, std_par) {
#   return(x * std_par['scale'] + std_par['mean'])
# }
# n_rounds = 1
# nu = 3; q = 0.9
# rb=.5
# quant = qchisq(1-q, nu)
# hyperpar['b'] = 0.5*var(sim$Y)/n_rounds;
# hyperpar['lambda'] = (var(sim$Y)*quant)/nu;
# hyperpar['tree_iter'] = 4; hyperpar['max_depth'] = 3;

# GSBart_Time = Sys.time()
# GSBres <- GenGSBart(sim$Y, 750, 250, 750, InputGraphs[1], graphs_weight, hyperpar, modelpar, 1, verbose = T, seed = 1234)
# GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
# GSBart_Y_out =  colMeans(GSBres$phi.train)
# GSBart_pred_unstandardized = Unstandardize(GSBart_Y_out, stdY$std_par)
# GSBart_MSPE = mean((Y0 - GSBart_pred_unstandardized)^2)
# GSBart_MAPE = mean(abs(GSBart_pred_unstandardized - Y0))
# print(GSBart_MSPE); print(GSBart_MAPE); print(GSBres$Move_count)

# save(GSBres, GSBart_Time, GSBart_pred_unstandardized, file = "~/Downloads/GSBart_rebuttal/Pwcnt/GSBPwcntonetree.Rdata")


# library(testthat)
# library(purrr)
# library(dplyr)
# library(bayestestR)
# load("~/Downloads/code/test_code/testUshapePwcntoneround.Rdata")

# Standardize = function(Y, std_par = NULL) {
#   if(is.null(std_par)) {
#     ymean = mean(Y)
#     yscale = 2 * max(abs(Y))
#   } else {
#     ymean = std_par['mean']
#     yscale = std_par['scale']
#   }
#   Y = (Y - ymean) / yscale
#   std_par = c('mean' = ymean, 'scale' = yscale)
#   return(list(Y = Y, std_par = std_par))
# }

# Unstandardize = function(x, std_par) {
#   return(x * std_par['scale'] + std_par['mean'])
# }
# n_rounds = 1
# nu = 3; q = 0.9
# rb=.5
# quant = qchisq(1-q, nu)
# hyperpar['b'] = 0.5*var(sim$Y)/n_rounds;
# hyperpar['lambda'] = (var(sim$Y)*quant)/nu;
# hyperpar['tree_iter'] = 4; hyperpar['max_depth'] = 3;

# GSBart_Time = Sys.time()
# GSBres <- GenGSBart(sim$Y, 750, 250, 750, InputGraphs[1], graphs_weight, hyperpar, modelpar, 1, verbose = T, seed = 1234)
# GSBart_Time = difftime(Sys.time(), GSBart_Time, units = "secs")
# GSBart_Y_out =  colMeans(GSBres$phi.train)
# GSBart_pred_unstandardized = Unstandardize(GSBart_Y_out, stdY$std_par)
# GSBart_MSPE = mean((Y0 - GSBart_pred_unstandardized)^2)
# GSBart_MAPE = mean(abs(GSBart_pred_unstandardized - Y0))
# print(GSBart_MSPE); print(GSBart_MAPE); print(GSBres$Move_count)
# print(GSBart_Time)

# save(GSBres, GSBart_Time, GSBart_pred_unstandardized, file = "~/Downloads/GSBart_rebuttal/Pwcnt/GSBUshapePwcntonetreesnew.Rdata")

library(testthat)
library(ggplot2)
library(ggpubr)
library(purrr)
library(caret)
library(xgboost)

load("~/Downloads/code/test_code/Ushapesim.Rdata")

num_ost = 5; n_train = 800; n_test = 200; p = 5
graphs_weight = c(rep((1-min(p / (p + 2), 0.85))/(num_ost + 2), (num_ost + 2)), rep(min(p / (p + 2), 0.85)/p,p))
noise = 0.15; repetitions = 50


message("Sampling Y")
repetition = 3
set.seed(1234+repetition)
sigma_y = noise
Y0 = sim$f_true + rnorm(n_train, 0, sigma_y)
Y0_ho = sim$f_ho_true + rnorm(n_test, 0, sigma_y)


bsbart <- function(Y_train, Graphs, ndpost, nskip, nkeep = ndpost, graphs_weight = rep(1/length(Graphs[[1]]),
                   length(Graphs[[1]])), hyperpar = NULL, modelpar = NULL, nthreads = 1, sparse = FALSE,
                   verbose = FALSE, seed = 1234){
  n_train = length(Y_train)
  pred_flag = !is.null(Graphs[[1]][[1]]$mesh2ho)
  if(length(graphs_weight)!=length(Graphs[[1]])){
    stop("The dimension of weight of graphs should match with the number of graphs")
  }
  if(nkeep > ndpost*length(Graphs)){
    stop("nkeep should be smaller than ndpost * number of graph sets")
  }
  ymean = mean(Y_train)
  yscale = 2 * max(abs(Y_train))
  Y = (Y_train - ymean) / yscale
  ntrees = length(Graphs)
  if(!is.null(hyperpar)){
    hyperpar_names = names(hyperpar)
    if(!("alpha" %in% hyperpar_names)){ hyperpar["alpha"] = 0.95}
    if(!("beta" %in% hyperpar_names)){hyperpar["beta"] = 2}
    if(!("a" %in% hyperpar_names)){ hyperpar["a"] = 3 }
    if(!("b" %in% hyperpar_names)){ hyperpar["b"] = 0.5*stats::var(Y)/ntrees }
    if(!("split_eps" %in% hyperpar_names)){ hyperpar["split_eps"] = 0}
    if(!("max_depth" %in% hyperpar_names)){ hyperpar["max_depth"] = 6}
    if(!("rb" %in% hyperpar_names)){hyperpar["rb"] = 0.5}
    if(!("nu" %in% hyperpar_names)){hyperpar["nu"] = 3}
    if(!("lambda" %in% hyperpar_names)){
      hyperpar["lambda"] = stats::var(Y)*stats::qchisq(0.1, hyperpar[['nu']])/hyperpar[['nu']]
    }
    if(!("eta" %in% hyperpar_names)){hyperpar["eta"] = 0.5}
    if(!("zeta" %in% hyperpar_names)){hyperpar["zeta"] = 1}
    if(!("rho" %in% hyperpar_names)){hyperpar["rho"] = length(Graphs[[1]])}
    if(!("tree_iter" %in% hyperpar_names)){hyperpar["tree_iter"] = 12}
  }else{
    hyperpar = list(alpha = 0.95, beta = 2, a = 3, split_eps = 0, max_depth = 6, rb = 0.5,
                    nu = 3, eta = 0.5, zeta = 1, rho = length(Graphs[[1]]), tree_iter = 12)
    hyperpar["b"] = 0.5* stats::var(Y)/ntrees
    hyperpar["lambda"] = stats::var(Y)*stats::qchisq(0.1,hyperpar[['nu']])/hyperpar[['nu']]

  }
  if(!is.null(modelpar)){
    modelpar_names = names(modelpar)
    if(!("tausq" %in% modelpar_names)){modelpar["tausq"] = ((max(Y)-min(Y))/(2*2*sqrt(ntrees)))^2 }
    if(!("sigmasq" %in% modelpar_names)){modelpar["sigmasq"] = stats::var(Y)}
    if(!("theta" %in% modelpar_names)){modelpar["theta"] = 0}
  }else{
    modelpar = list(tausq = ((max(Y)-min(Y))/(2*sqrt(ntrees)))^2, sigmasq = stats::var(Y),
                    theta = 0)
  }
  const_theta = T
  if(modelpar[['theta']] == 0){const_theta = F; modelpar[['theta']] = 1}
  output = GSBart(Y, ndpost, nskip, nkeep, Graphs, graphs_weight, hyperpar, modelpar,
                  nthreads, pred_flag, sparse, const_theta, verbose, seed)
  if(pred_flag){
    output$yhat.train = (output$phi.train) * yscale + ymean
    output$yhat.test = (output$phi.test) * yscale + ymean
    output$yhat.train.mean = colMeans(output$yhat.train)
    output$yhat.test.mean = colMeans(output$yhat.test)
    output$phi.train <- NULL; output$phi.test <- NULL
  }else{
    output$yhat.train = (output$phi.train) * yscale + ymean
    output$yhat.train.mean = colMeans(output$yhat.train)
    output$phi.train <- NULL
  }
  return(output)
}

tmp = bsbart(Y0, sim$Graphs, 40, 15, 40, graphs_weight = graphs_weight, nthreads = 7, verbose = T)