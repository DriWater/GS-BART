#' @importFrom Rcpp evalCpp
#' @useDynLib GSBart, .registration = TRUE
NULL