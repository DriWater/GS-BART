#pragma once

// Why don't you come on over valarray?
#include <valarray>
#include <vector>
#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::plugins(cpp17)]]

#include "aggregator.h"
#include "debug_msg.h"

// typedef std::pair<arma::mat, arma::mat> TaylorExpansion;

class Gradients {
public:
  arma::uvec leaf;
  arma::uvec vertex;
  arma::uvec cnt; 
  arma::vec em;
  
  // Gradients(const unsigned int n) {
  //   DEBUG_MSG("Gradients default constructor");
  //   leaf.zeros(n);
  //   vertex.zeros(n);
  //   Gs.zeros(n);
  //   Hs.zeros(n);
  // }
  
  ~Gradients() {
    //DEBUG_MSG("Gradients destructor");
  }
  
  Gradients(const arma::uvec &leaf_inp, const arma::uvec &vertex_inp, const arma::uvec &cnt_inp, 
            const arma::vec &em_inp) {
    //DEBUG_MSG("Gradients manual constructor");
    unsigned int n = leaf_inp.n_elem;
    // unsigned int k = em_inp.n_cols;
    leaf = arma::uvec{leaf_inp.memptr(), n};
    vertex = arma::uvec{vertex_inp.memptr(), n};
    cnt = arma::uvec{cnt_inp.memptr(), n};
    em = arma::vec{em_inp.memptr(), n};
  }
  
  
  // Equivalent to aggregate(gradients_i, by = list(vertex=graph_attr(x$g)$tr2mesh, 
  //                                                leaf=ids), FUN=sum)
  Gradients(const arma::vec &em_inp, const arma::uvec &ids, const std::vector<unsigned int> &tr2mesh) {
    //DEBUG_MSG("Gradients aggregate constructor");
    //const unsigned int n = tr2mesh.size();
    //DEBUG_MSG("Gradients aggregate constructor: allocated variables");
    unsigned int n = ids.n_elem;
    arma::umat groupingVars = arma::join_rows(ids, arma::uvec(tr2mesh));
    arma::vec ids_num(n, arma::fill::ones);
    // DEBUG_MSG("Gradients aggregate constructor: defined grouping variables");
    arma::mat gradients_i_vec = arma::join_rows(ids_num, em_inp);
    // arma::mat gradients_i_vec = arma::join_rows(gradients_i.first,  gradients_i.second);
    // unsigned int levels = em_inp.n_cols;
    // DEBUG_MSG("Gradients aggregate constructor: defined gradients_i_vec variables");
    // std::function<arma::rowvec(arma::rowvec, arma::rowvec)> myAdderFunc = [](arma::rowvec i, arma::rowvec j){return i + j;};
    // auto aggregatedGrads = groupBy(gradients_i_vec, groupingVars);
    auto aggregatedGrads = groupBy(gradients_i_vec, groupingVars);
    // DEBUG_MSG("Gradients aggregate constructor: finished aggregation");
    leaf = aggregatedGrads.second.col(0);
    vertex = aggregatedGrads.second.col(1);
    cnt = arma::conv_to<arma::umat>::from(aggregatedGrads.first.col(0));
    em = aggregatedGrads.first.col(1);
    // DEBUG_MSG("Gradients aggregate constructor: finished");
  }
  
  Gradients(const Gradients &gradients) {
    //DEBUG_MSG("Gradients copy constructor");
    //unsigned int n = gradients.leaf.n_elem;
    leaf = arma::uvec{gradients.leaf};
    vertex = arma::uvec{gradients.vertex};
    cnt = arma::uvec{gradients.cnt};
    em = arma::vec{gradients.em};
  }
  
  Gradients filter(const unsigned int v) const {
    arma::uvec mask = arma::find(vertex == v);
    Gradients filtered(leaf.elem(mask), vertex.elem(mask), cnt.elem(mask), em.elem(mask));
    return(filtered);
  }
  
};
