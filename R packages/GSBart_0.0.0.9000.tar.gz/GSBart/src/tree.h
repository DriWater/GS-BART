#pragma once

#ifndef GUARD_tree_h
#define GUARD_tree_h

#include <map>
#include <cmath>
#include <cstddef>

#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]


#include "common.h"


//--------------------------------------------------
//xinfo xi, then xi[v][c] is the c^{th} cutpoint for variable v.
//left if x[v] < xi[v][c]
typedef std::vector<double> vec_d; //double vector
// typedef std::vector<vec_d> xinfo; //vector of vectors, will be split rules

//--------------------------------------------------
//info contained in a node, used by input operator
struct node_info {
   unsigned int id; //node id
   unsigned int v;  //variable
   unsigned int c; //cut point
   double mu;   //theta
   unsigned int lid; //leaf ids 
   double esn; //edges splittable num
   unsigned int lty;
   // unsigned int c;  //cut point
};

//--------------------------------------------------
class tree {
public:
   //friends--------------------
   friend std::istream& operator>>(std::istream&, tree&);
   //typedefs--------------------
   typedef tree* tree_p;
   typedef const tree* tree_cp;
   typedef std::vector<tree_p> npv; 
   typedef std::vector<tree_cp> cnpv;
   //contructors,destructors--------------------
   tree(): mu(0.0), v(0),c(0),p(0),l(0),r(0),lid(0), esn(0.0), lty(0) {}
   tree(const tree& n): mu(0.0), v(0),c(0),p(0),l(0),r(0),lid(0), esn(0.0), lty(0) {cp(this,&n);}
   tree(double imu): mu(imu), v(0),c(0),p(0),l(0),r(0),lid(0), esn(0.0), lty(0) {}
   void tonull(); //like a "clear", null tree has just one node
   ~tree() {tonull();}
   //operators----------
   tree& operator=(const tree&);
   //interface--------------------
   //set
   // void settheta(double theta) {this->theta=theta;}
   void setv(unsigned int v) {this->v = v;}
   void setc(unsigned int c) {this->c = c;}
   void setlid(unsigned int lid) {this->lid = lid;}
   void setmu(double mu) {this->mu = mu;}   
   void setesn(double esn) {this->esn = esn;}
   void setlty(unsigned int lty) {this->lty = lty;}      
   //get
   double getmu() const {return mu;}
   unsigned int getv() const {return v;}
   unsigned int getc() const {return c;}
   unsigned int getlid() const {return lid;}
   double getesn() const {return esn;}   
   unsigned int getlty() const {return lty;}
   tree_p getp() {return p;}  
   tree_p getl() {return l;}
   tree_p getr() {return r;}
   //tree functions--------------------
   tree_p getptr(unsigned int nid); //get node pointer from node id, 0 if not there
   tree_p getpbtr(unsigned int lid); //get bottom node pointer from leaf node id, 0 if not there
   void pr(bool pc=true); //to screen, pc is "print children"
   unsigned int treesize(); //number of nodes in tree
   unsigned int nnogs();    //number of nog nodes (no grandchildren nodes)
   unsigned int nbots();    //number of bottom nodes
   bool birth(unsigned int nid, unsigned int v, unsigned int c, double esn, unsigned int lidr, unsigned int ltyl, unsigned int ltyr);
   bool death(unsigned int nid);
   void birthp(tree_p np, unsigned int v, unsigned int c, double esn, unsigned int lidr, unsigned int ltyl, unsigned int ltyr);
   void deathp(tree_p n);
   void varcount(std::vector<unsigned int>& vcnt);
   void getbots(npv& bv);         //get bottom nodes
   void getnogs(npv& nv);         //get nog nodes (no granchildren)
   void getsbots(npv &bv);
   void getnodes(npv& v);         //get vector of all nodes
   void getnodes(cnpv& v) const;  //get vector of all nodes (const)
   void getprior(std::vector<double> &tree_lprlik, const std::vector<double> &alpha_vec, const double &beta);
   bool ismergeable();
   // void getrules(arma::uvec &esnvec, arma::vec &gswvec, unsigned int &node_id);
   // tree_p bn(double *x,xinfo& xi); //find Bottom Node
   // void rg(unsigned int v, int* L, int* U); //recursively find region [L,U] for var v
   //node functions--------------------
   unsigned int nid() const; //nid of a node
   unsigned int depth();  //depth of a node
   char ntype(); //node type t:top, b:bot, n:no grandchildren i:interior (t can be b)
   char mtype(); // merge type n:no grandchildren, f:four grandchildren, t:two grandchildren
   bool isnog();
   // unsigned int getbadcut(unsigned int v);
   /*
#ifndef NoRcpp   
  Rcpp::List tree2list(xinfo& xi, double center=0., double scale=1.); // create an efficient list from a single tree
  //tree list2tree(Rcpp::List&, xinfo& xi); // create a tree from a list and an xinfo  
  Rcpp::IntegerVector tree2count(unsigned int nvar); // for one tree, count the number of branches for each variable
#endif
   */
private:
   // double theta; //univariate double parameter
   //rule: left if x[v] < xinfo[v][c]
   double mu;
   unsigned int v; // graph split index 
   unsigned int c; // edge remove index 
   //tree structure
   tree_p p; //parent
   tree_p l; //left child
   tree_p r; //right child
   unsigned int lid; //leaf ids 
   double esn; //edges splittable num
   unsigned int lty;  // leaf node type: '0':alive; '1':stop; 
   //utiity functions
   void cp(tree_p n,  tree_cp o); //copy tree
};
std::istream& operator>>(std::istream&, tree&);
std::ostream& operator<<(std::ostream&, const tree&);

#endif
