#include "utilfuncs.h"

arma::uvec find_indices(const arma::uvec& tmp1, const arma::uvec& tmp2){
  std::unordered_set<unsigned int> hash_set(tmp2.begin(), tmp2.end());
  std::vector<arma::uword> indices;
  for (arma::uword i = 0; i < tmp1.n_elem; ++i) {
    if (hash_set.find(tmp1[i]) != hash_set.end()) {
      indices.push_back(i);
    }
  }
  return arma::uvec(indices);
}

arma::uvec get_ranks(const arma::uvec& tmp){
  arma::uvec unique_vals = arma::unique(tmp);
  std::map<unsigned int, arma::uword> rank_map;
  for (arma::uword i = 0; i < unique_vals.n_elem; ++i) {
    rank_map[unique_vals[i]] = i;
  }
  arma::uvec ranks(tmp.n_elem);
  for (arma::uword i = 0; i < tmp.n_elem; ++i) {
    ranks[i] = rank_map[tmp[i]];
  }
  return ranks;
}

std::vector<double> flatten(const std::vector<std::vector<std::vector<double>>>& vec3d){
  unsigned int total_size = 0;
  for (const auto& layer : vec3d){
    for(const auto& row : layer){
      total_size += row.size();
    }
  }
  std::vector<double> result; result.reserve(total_size);
  for (const auto& layer : vec3d){
    for (const auto& row : layer){
      result.insert(result.end(), row.begin(), row.end());
    }
  }
  return result;
}

std::vector<unsigned int> RowSums(const std::vector<std::vector<unsigned int>>& data){
  std::vector<unsigned int> rowSums;
  for (const auto& row : data) {
    rowSums.push_back(std::accumulate(row.begin(), row.end(), 0));
  }
  return rowSums;
}

double log_sum_exp(std::vector<double>& v){
    //double mx=v[0],sm=0.;
    double totalsum = 0.0;
    double max_val = *std::max_element(v.begin(), v.end());
    std::for_each(v.begin(), v.end(), [max_val](double& val){
          val -= max_val;
    });
    // for(unsigned int i=0;i<v.size();i++) if(v[i]>mx) mx=v[i];
    for(unsigned int i=0;i<v.size();i++){
      totalsum += exp(v[i]);
    }
    return (log(totalsum) + max_val);
}

double log_sum_exp2(std::vector<double>& v)
{
  double mx=v[0],sm=0.;
  for(size_t i=0;i<v.size();i++) if(v[i]>mx) mx=v[i];
  for(size_t i=0;i<v.size();i++){
    sm += exp(v[i]-mx);
  }
  return mx+log(sm);
}


GraphInfo infoPass(OST &graph, const Gradients &gradients, const unsigned int v,
                   const unsigned int nc, const unsigned int n){
  // graph.info contains vectors of gradient information for each cluster/leaf node index
  // DEBUG_MSG("Computing infoPass at " << v);
  GraphInfo outputGI(nc, n);
  // gradient info at vertex v
  Gradients df_c = gradients.filter(v);
  // gradient info at leaf vertices
  // DEBUG_MSG("Found filtered gradients df_c");
  unsigned int n_children = graph.numChildren(v);
  if(n_children == 0) {
    //DEBUG_MSG("Updating gradients at leaf vertex " << v);
    arma::uvec col_idx = {v};
    outputGI.Gs_R(df_c.leaf, col_idx) = df_c.Gs;
    outputGI.Hs_R(df_c.leaf, col_idx) = df_c.Hs;
    outputGI.Hs_mu_R(df_c.leaf, col_idx) = df_c.Hs_mu;
    outputGI.cnt_R(df_c.leaf, col_idx) = df_c.cnt;
    outputGI.Prop(df_c.leaf, col_idx) = (df_c.cnt > 0);
  } else {
    // gradient info at non-leaf vertices
    // DEBUG_MSG("Updating gradients at non-leaf vertex " << v);
    /* #ifdef _OPENMP
#pragma omp taskloop default(none) shared(v, n_children, graph, gradients, nc, n) num_tasks(n_children) untied reduction(+:outputGI)
#endif */
     arma::ucolvec splittable_children_cnt(nc, arma::fill::zeros);
     for(unsigned int child = 0; child < n_children; ++child) {
       unsigned int child_idx = graph.getChild(v, child);
       GraphInfo branch = infoPass(graph, gradients, child_idx, nc, n);
       /*#ifdef _OPENMP
#pragma omp taskyield// If other threads are busy, go help them instead
#endif
#ifdef _OPENMP
#pragma omp task in_reduction(+:outputGI) // All of the below needs to be done together as part of the outputGI calculation
#endif
        {*/
       outputGI += branch;
       outputGI.Gs_R.col(v) += branch.Gs_R.col(child_idx);
       outputGI.Hs_R.col(v) += branch.Hs_R.col(child_idx);
       outputGI.Hs_mu_R.col(v) += branch.Hs_mu_R.col(child_idx);
       outputGI.cnt_R.col(v) += branch.cnt_R.col(child_idx);
       outputGI.Prop.col(v) += branch.Prop.col(child_idx);
       splittable_children_cnt += (branch.cnt_R.col(child_idx) > 0);
     }
    outputGI.Gs_R(df_c.leaf, arma::uvec{v}) += df_c.Gs;
    outputGI.Hs_R(df_c.leaf, arma::uvec{v}) += df_c.Hs;
    outputGI.Hs_mu_R(df_c.leaf, arma::uvec{v}) += df_c.Hs_mu;
    outputGI.cnt_R(df_c.leaf, arma::uvec{v}) += df_c.cnt;
    if(df_c.cnt.is_empty()){
      outputGI.Prop.col(v) = (splittable_children_cnt > 1);
    }else{
      arma::ucolvec tmp(nc, arma::fill::zeros);
      tmp(df_c.leaf) = (df_c.cnt > 0);
      tmp +=  (splittable_children_cnt > 1);
      outputGI.Prop.col(v) = (tmp>0);
    }
  }
  // DEBUG_MSG("Finished infoPass at " << v);
  return(outputGI);
}

arma::vec EvalLikRatio(const arma::vec &Gs_L, const arma::vec &Gs_R, const arma::vec &Hs_L, const arma::vec &Hs_R, const arma::vec &Hs_mu_L,
                       const arma::vec &Hs_mu_R, const double &mu0, const double &tausq){
  arma::vec logdetdiff; arma::vec quaddiff;
  logdetdiff = 0.5*(arma::log(1/tausq - Hs_L - Hs_R) - arma::log(1/tausq - Hs_L) -
                    arma::log(1/tausq - Hs_R) - std::log(tausq));
  quaddiff = 0.5*(arma::square(Gs_L - Hs_mu_L + mu0/tausq)/(1/tausq - Hs_L) +
                  arma::square(Gs_R - Hs_mu_R + mu0 /tausq)/(1/tausq - Hs_R) -
                  arma::square(Gs_L + Gs_R - Hs_mu_L - Hs_mu_R + mu0 /tausq)/(1/tausq -Hs_L - Hs_R) -
                  std::pow(mu0,2)/tausq);
  return(logdetdiff+quaddiff);
}

double EvalLikRatio(const double &Gs_L, const double &Gs_R, const double &Hs_L, const double &Hs_R, const double &Hs_mu_L,
                    const double &Hs_mu_R, const double &mu0, const double &tausq){
  double logdetdiff = 0.5*(std::log(1/tausq - Hs_L) + std::log(1/tausq - Hs_R) + std::log(tausq)
                    - std::log(1/tausq - Hs_L - Hs_R));
  double quaddiff = 0.5*(std::pow((Gs_L + Gs_R - Hs_mu_L - Hs_mu_R + mu0 /tausq),2)/(1/tausq - Hs_L - Hs_R) +
                  std::pow(mu0,2)/tausq - std::pow((Gs_L - Hs_mu_L + mu0/tausq),2)/(1/tausq - Hs_L) -
                  std::pow((Gs_R - Hs_mu_R + mu0 /tausq),2)/(1/tausq - Hs_R));
  return(logdetdiff+quaddiff);
}

void GraphSplitLik(OST &graph, const Gradients &gradients, const arma::colvec &Gs_sum, arma::colvec &Hs_sum, const arma::colvec &Hs_mu_sum, 
                   const arma::ucolvec &cnt_sum, const std::vector<double> &log_A_vec, const std::vector<double> &log_prior_child_vec, 
                   const std::vector<double> &log_n_prunable_vec, std::vector<std::vector<double>> &SpL2Dvec, std::vector<std::vector<unsigned int>> &idx2Dvec, 
                   std::vector<unsigned int> &esn, const double &log_graph_weight, const unsigned int &iter, const double &rb, const double &rd, const double &mu0, 
                   const double &tausq, const unsigned int &split_eps){
  DEBUG_MSG("Entering splitGraph");
  unsigned int n_splittable = cnt_sum.n_rows;
  // const unsigned int nc =  cnt_sum.n_rows;
  const unsigned int n_v = graph.numVerts(); 
  // GraphInfo outputGI(n_splittable, nv);
  // const unsigned int n_roots = graph.numRoots();
  const std::vector<unsigned int> g_roots = graph.getRoots();
  // DEBUG_MSG("Recursing at " << n_roots << " roots"); // should always be one
  unsigned int r = g_roots[0];
  GraphInfo outputGI = infoPass(graph, gradients, r, n_splittable, n_v);
  // DEBUG_MSG("Declared outputGI");
  arma::umat cnt_L = cnt_sum - outputGI.cnt_R.each_col();
  arma::umat Prop_mat = outputGI.Prop && (cnt_L > split_eps) && (outputGI.cnt_R > split_eps);  // 1 is proper 0 otherwise
  arma::uvec esnvec = arma::sum(Prop_mat, 1); esn = arma::conv_to<std::vector<unsigned int>>::from(esnvec);
  unsigned int propcnt = arma::accu(esnvec);
  if(propcnt>0){
    // std::copy(esnvec.begin(), esnvec.end(), esn.begin() + (iter*n_splittable));
    for(unsigned int i = 0; i < n_splittable; ++i){
      if(esnvec(i) > 0){
        arma::uvec rowid = {i};
        arma::uvec edgeidx = arma::find(Prop_mat.row(i) == 1);
        arma::vec Gs_R_vec = arma::conv_to<arma::vec>::from(outputGI.Gs_R(rowid, edgeidx));
        arma::vec Hs_R_vec = arma::conv_to<arma::vec>::from(outputGI.Hs_R(rowid, edgeidx));
        arma::vec Hs_mu_R_vec = arma::conv_to<arma::vec>::from(outputGI.Hs_mu_R(rowid, edgeidx));
        arma::uvec cnt_R_vec = arma::conv_to<arma::uvec>::from(outputGI.cnt_R(rowid, edgeidx));
        arma::vec Gs_L_vec = Gs_sum(i) - Gs_R_vec; arma::vec Hs_L_vec = Hs_sum(i) - Hs_R_vec;
        arma::vec Hs_mu_L_vec = Hs_mu_sum(i) - Hs_mu_R_vec;
        arma::uvec splittable_child_vec = arma::conv_to<arma::uvec>::from(cnt_L(rowid, edgeidx)>(2*split_eps+1)) + (cnt_R_vec >(2*split_eps+1));
        arma::vec log_L_vec = EvalLikRatio(Gs_L_vec, Gs_R_vec, Hs_L_vec, Hs_R_vec, Hs_mu_L_vec, Hs_mu_R_vec, mu0, tausq);
        arma::vec Log_likelihood_vec = std::log(rd) + std::log(rb) - 2 * std::log(esnvec(i)) - std::log((double) n_splittable) 
                                     - log_n_prunable_vec[i] + 2 * log_graph_weight + log_L_vec + log_A_vec[i] 
                                     + arma::conv_to<arma::vec>::from(splittable_child_vec) * log_prior_child_vec[i];
        SpL2Dvec[i] = arma::conv_to<std::vector<double>>::from(Log_likelihood_vec);
        idx2Dvec[i] = arma::conv_to<std::vector<unsigned int>>::from(edgeidx); 
      }
    }
    DEBUG_MSG("Completed an infoPass recursion");
  }

}

void SpLik(std::vector<OST> &graphs, const arma::vec &Gs, const arma::vec &Hs, const arma::vec &muhat, const arma::uvec &train_cids, 
           const std::vector<double> &log_n_prunable_vec, const std::vector<double> &lgw, const std::vector<double> &log_A_vec, 
           const std::vector<double> &log_prior_child_vec, std::vector<std::vector<std::vector<double>>> &SpL3Dvec, 
           std::vector<std::vector<std::vector<unsigned int>>> &idx3Dvec, std::vector<std::vector<unsigned int>> &esnmat, 
           const arma::uvec &split_indices, const double &tausq, const double &mu0, const unsigned int &split_eps, 
           const unsigned int &n_splittable, const double &rb, const double &rd){
  DEBUG_MSG("Start Split Likelihood Cal");
  unsigned int n_graphs =  graphs.size();
  unsigned int n =  Gs.n_elem;
  arma::vec Hs_mu = Hs % muhat;
  arma::vec ids_num(n, 1, arma::fill::ones);
  arma::umat groupingVars(n, 1);  groupingVars.col(0) = train_cids;
  arma::mat gradients_i_vec = arma::join_rows(ids_num, arma::join_rows(Gs, arma::join_rows(Hs, Hs_mu)));
  auto aggregatedGrads = groupBy(gradients_i_vec, groupingVars);
  arma::ucolvec leaf_order = arma::sort_index(aggregatedGrads.second.col(0));
  arma::ucolvec cnt_sum = arma::conv_to<arma::ucolvec>::from(aggregatedGrads.first.col(0));
  cnt_sum = cnt_sum(leaf_order);
  arma::colvec Gs_sum = aggregatedGrads.first.col(1); Gs_sum = Gs_sum(leaf_order);
  arma::colvec Hs_sum = aggregatedGrads.first.col(2); Hs_sum = Hs_sum(leaf_order);
  arma::colvec Hs_mu_sum = aggregatedGrads.first.col(3); Hs_mu_sum = Hs_mu_sum(leaf_order); 
  #ifdef _OPENMP
  #pragma omp parallel for shared(n_graphs, graphs, split_indices, Gs, Hs, muhat, train_cids, Gs_sum, Hs_sum, Hs_mu_sum, cnt_sum, log_A_vec, \
          log_prior_child_vec, log_n_prunable_vec, SpL3Dvec, idx3Dvec, esnmat, lgw, rb, rd, mu0, tausq, split_eps)
  #endif
  for(unsigned int g = 0; g < n_graphs; ++g){
    std::vector<unsigned int> inptr2mesh(graphs[g].getGraphAttr<std::vector<unsigned int>>("tr2mesh"));
    std::vector<unsigned int> tr2mesh_tmp;
    for(auto idx : split_indices) {
      tr2mesh_tmp.push_back(inptr2mesh[idx]);
    }
    Gradients inpGrads{Gs, Hs, muhat, train_cids, tr2mesh_tmp};
    DEBUG_MSG("Calculated inpGrads");
    GraphSplitLik(graphs[g], inpGrads, Gs_sum, Hs_sum, Hs_mu_sum, cnt_sum, log_A_vec, log_prior_child_vec, log_n_prunable_vec, 
                  SpL3Dvec[g], idx3Dvec[g], esnmat[g], lgw[g], g, rb, rd, mu0, tausq, split_eps);
  }

  DEBUG_MSG("Done Split Likelihood Cal");
}

double MeLik(const arma::vec &Gs, const arma::vec &Hs, const arma::vec &muhat, const arma::uvec &train_cids, 
             tree::tree_p &node_prunable, const std::vector<double> &lgw, const unsigned int &n_splittable, 
             const unsigned int &n_prunable, const unsigned int &splittable_children_cnt, const double &tausq, 
             const double &alpha,  const double &beta, const double &mu0, const double &rb, const double &rd){
    tree::tree_p nl = node_prunable->getl(); tree::tree_p nr = node_prunable->getr();
    unsigned int lidl = nl->getlid(); unsigned int lidr = nr->getlid();
    arma::uvec splittable_child_l = arma::find(train_cids == lidl);
    arma::uvec splittable_child_r = arma::find(train_cids == lidr);
    double log_prior_children = 0.0; unsigned int depth = node_prunable->depth(); 
    if(splittable_children_cnt == 1){log_prior_children = std::log(1.0 - alpha * std::pow((2.0 + depth), (-beta)));}
    else if(splittable_children_cnt == 2){log_prior_children = 2 * std::log(1.0 - alpha * std::pow((2.0 + depth), (-beta)));}
    unsigned int graph_id = node_prunable->getv(); unsigned int esn = node_prunable->getesn(); 
    double log_A = -(std::log(alpha) - beta*(std::log(1.0 + depth)) + log_prior_children 
                 - std::log(1.0-alpha * std::pow((1.0 + depth),(-beta))) 
                 + lgw[graph_id] - std::log((double) esn));
    double log_P = std::log(rb) + std::log(rd) +  lgw[graph_id] - std::log((double) esn)
                 - std::log((double) n_splittable) - std::log((double) n_prunable);
    double Gs_L = arma::accu(Gs(splittable_child_l)); double Gs_R = arma::accu(Gs(splittable_child_r));
    double Hs_L = arma::accu(Hs(splittable_child_l)); double Hs_R = arma::accu(Hs(splittable_child_r));
    arma::vec Hs_mu = Hs % muhat;
    double Hs_mu_L = arma::accu(Hs_mu(splittable_child_l)); double Hs_mu_R = arma::accu(Hs_mu(splittable_child_r));
    double log_L = EvalLikRatio(Gs_L, Gs_R, Hs_L, Hs_R, Hs_mu_L, Hs_mu_R, mu0, tausq);
    double log_acc_prob = log_A + log_P + log_L;
    return(log_acc_prob);
}

double MeLik(tree::tree_p &node_prunable, const std::vector<double> &lgw, const unsigned int &n_splittable,
             const unsigned int &n_prunable, const double &log_S, const double &rb, const double &rd){
    unsigned int graph_id = node_prunable->getv(); unsigned int esn = node_prunable->getesn(); 
    double log_P = std::log(rb) + std::log(rd) + lgw[graph_id] - std::log((double) esn)
                 - std::log((double) n_splittable) - std::log((double) n_prunable);
    double log_acc_prob = 2 * log_P - log_S;
    return(log_acc_prob);
}

double DrawMu(tree &Ptree, const arma::vec &Gs, const arma::vec &Hs, const arma::vec &muhat, arma::vec &muhat_new, 
              arma::vec &muhat_ho_new, const arma::uvec &train_ids, const arma::uvec &test_ids,
              const unsigned int &lid, const double &tausq, const double &mu0, rn& gen){
  double Gs_sum = arma::accu(Gs(train_ids));
  double Hs_sum = arma::accu(Hs(train_ids));
  double Hs_mu_sum = arma::accu(Hs(train_ids) % muhat(train_ids));
  tree::tree_p bottom_node = Ptree.getpbtr(lid);
  double a = Gs_sum - Hs_mu_sum + mu0/tausq; 
  double b = 1/tausq - Hs_sum;
  double mu = (a/b + gen.normal()/std::sqrt(b));    
  muhat_new(train_ids).fill(mu);
  if(test_ids.n_elem > 0){
    muhat_ho_new(test_ids).fill(mu); 
  }
  bottom_node->setmu(mu); 
  return(mu); 
}

bool SplitAdj(std::vector<OST> &graphs, tree &Ptree, const arma::vec &Gs, const arma::vec &Hs, const arma::vec &muhat, arma::vec &muhat_new, 
              arma::vec &muhat_ho_new, arma::uvec &train_cids, arma::uvec &test_cids, std::vector<std::vector<std::vector<double>>> &SpL3Dvec, 
              const double &log_S, std::vector<std::vector<std::vector<unsigned int>>> &idx3Dvec, std::vector<std::vector<unsigned int>> &esnmat,
              std::vector<double> &MeLvec, std::vector<double> &lgw, std::vector<double> &muvec, std::vector<double> &n_splittable_vec,
              std::vector<double> &n_prunable_vec, tree::npv &nodes_splittable, tree::npv &nodes_prunable, unsigned int &n_splittable, unsigned int &n_prunable, 
              const unsigned int &graph_id, const unsigned int &edge_split, const unsigned int &node_split_id, const double &alpha, const double &beta, 
              const unsigned int &max_depth, const double &tausq, const double &mu0, const unsigned int &split_eps, const double &rb, rn &gen){
  tree::tree_p node_split = nodes_splittable[node_split_id];    
  bool stop_update = false; unsigned int n_leaf = idx3Dvec[0].size(); 
  unsigned int node_depth =  node_split->depth() + 1;
  if(node_depth>=max_depth){ stop_update = true; return(stop_update);} 
  unsigned int split_lid = node_split->getlid();
  unsigned int nc = (arma::max(train_cids) + 1);
  graphs[graph_id].splitIndices(edge_split, split_lid, train_cids, test_cids, nc);
  arma::uvec train_ids_l = arma::find(train_cids == split_lid); 
  arma::uvec train_ids_r = arma::find(train_cids == nc);
  arma::uvec test_ids_l = arma::find(test_cids == split_lid);
  arma::uvec test_ids_r = arma::find(test_cids == nc);     
  unsigned int lcnt = train_ids_l.n_elem; 
  unsigned int rcnt = train_ids_r.n_elem;
  unsigned int ltyl = lcnt > (2*split_eps + 1) ? 0 : 1;
  unsigned int ltyr = rcnt > (2*split_eps + 1) ? 0 : 1; 
  unsigned int splittable_children_cnt = ((ltyl==0)+(ltyr == 0));
  unsigned int n_splittable_new = n_splittable + splittable_children_cnt - 1;
  double esn = esnmat[graph_id][node_split_id]; tree::tree_p parent_split_node; 
  bool mergeable = false; unsigned int n_graphs = idx3Dvec.size();
  std::vector<double> n_prunable_vec_new = n_prunable_vec; 
  std::vector<double> n_splittable_vec_new = n_splittable_vec; 
  std::transform(n_splittable_vec_new.begin(), n_splittable_vec_new.end(), n_splittable_vec_new.begin(), 
                 [splittable_children_cnt](double x) { return x + splittable_children_cnt - 1.0;});
  unsigned int n_prunable_new = n_prunable; tree::npv nodes_splittable_new; nodes_splittable_new.clear(); 
  if(node_split->ntype() != 't'){
    parent_split_node = node_split->getp();
    mergeable = parent_split_node->ismergeable();
  }
  if(mergeable){
    tree::tree_p nl = parent_split_node -> getl(); tree::tree_p nr = parent_split_node -> getr(); 
    tree::tree_p nadd = (nl == node_split)? (nr):(nl); 
    for(unsigned int i = 0; i < nodes_splittable.size(); i++){
      if(nodes_splittable[i] == nadd){ n_prunable_vec_new[i] += 1; break;}
    }
  }else{
    n_prunable_new += 1; 
    std::transform(n_prunable_vec_new.begin(), n_prunable_vec_new.end(), 
                   n_prunable_vec_new.begin(), [](double x) { return x + 1.0;});
  }
  Ptree.birthp(node_split, graph_id, edge_split, esn, nc, ltyl, ltyr);
  muvec[split_lid] = DrawMu(Ptree, Gs, Hs, muhat, muhat_new, muhat_ho_new, train_ids_l, test_ids_l, split_lid, tausq, mu0, gen); 
  double munew = DrawMu(Ptree, Gs, Hs, muhat, muhat_new, muhat_ho_new, train_ids_r, test_ids_r, nc, tausq, mu0, gen);
  muvec.push_back(munew); int j = n_leaf - 1;
  while(j>=0){
    if(j != (int) node_split_id){
      double diff = std::log(n_prunable_vec_new[j]) - std::log(n_prunable_vec[j])
                  + std::log(n_splittable_new) - std::log(n_splittable) ;
      for(unsigned int i = 0; i < n_graphs; ++i){
        for (auto it = SpL3Dvec[i][j].begin(); it != SpL3Dvec[i][j].end(); ++it){ *it -= diff;}
      }
    }else{
      if(ltyl == 0){ 
        nodes_splittable[node_split_id] = node_split->getl();
        n_prunable_vec_new[node_split_id] = (double) n_prunable_new; 
        nodes_splittable_new.push_back(node_split->getl());}
      else{
        nodes_splittable.erase(nodes_splittable.begin() + node_split_id);
        n_prunable_vec_new.erase(n_prunable_vec_new.begin() + node_split_id);
        for(unsigned int i = 0; i < n_graphs; ++i){
          SpL3Dvec[i].erase(SpL3Dvec[i].begin() + node_split_id);
          idx3Dvec[i].erase(idx3Dvec[i].begin() + node_split_id);
          esnmat[i].erase(esnmat[i].begin() + node_split_id);
        }
      }
    }
    j --;
  }
  if(ltyr == 0){
    nodes_splittable.push_back(node_split->getr());
    n_prunable_vec_new.push_back((double) n_prunable_new);
    nodes_splittable_new.push_back(node_split->getr());
  }    
  if(splittable_children_cnt > 0){
    std::vector<double>  log_A_vec(splittable_children_cnt, 0); arma::uvec lidv(splittable_children_cnt, arma::fill::zeros);
    std::vector<double> log_prior_child_vec(splittable_children_cnt, 0);
    for(unsigned int i = 0; i < splittable_children_cnt; i++){
      lidv(i) = nodes_splittable_new[i]->getlid();
      unsigned int node_depth = nodes_splittable_new[i]->depth();
      log_A_vec[i] = std::log(alpha) - beta * std::log(1.0 + node_depth) 
                   - std::log(1.0 - alpha * std::pow((1.0 + node_depth), (-beta)));
      log_prior_child_vec[i] = std::log(1-alpha * std::pow((2.0 + node_depth), (-beta)));
    }
    arma::uvec split_indices = find_indices(train_cids, lidv);
    arma::uvec train_cids_splittable = train_cids.elem(split_indices);
    arma::uvec train_cids_splittable_rank = get_ranks(train_cids_splittable);
    std::vector<std::vector<std::vector<double>>> SpL3Dvecnew(n_graphs, 
      std::vector<std::vector<double>>(splittable_children_cnt, std::vector<double>()));
    std::vector<std::vector<std::vector<unsigned int>>> idx3Dvecnew(n_graphs, 
      std::vector<std::vector<unsigned int>>(splittable_children_cnt, std::vector<unsigned int>()));
    std::vector<std::vector<unsigned int>> esnmatnew(n_graphs, std::vector<unsigned int>(splittable_children_cnt, 0)); 
    std::vector<double> log_n_prunable_vec(splittable_children_cnt, std::log((double) n_prunable_new));
    double rb_tmp = n_splittable_new>1 ? rb : 1;
    SpLik(graphs, Gs(split_indices), Hs(split_indices), muhat(split_indices), train_cids_splittable_rank, 
          log_n_prunable_vec, lgw, log_A_vec, log_prior_child_vec, SpL3Dvecnew, idx3Dvecnew, esnmatnew, 
          split_indices, tausq, mu0, split_eps, n_splittable_new, rb_tmp, 1-rb);
    unsigned int cnt = 0; 
    if(ltyl == 0){
      for(unsigned int i = 0; i < n_graphs; ++i){
        idx3Dvec[i][node_split_id] = idx3Dvecnew[i][cnt];
        SpL3Dvec[i][node_split_id] = SpL3Dvecnew[i][cnt];
        esnmat[i][node_split_id] = esnmatnew[i][cnt];
      }
      cnt ++;
    }
    if(ltyr == 0){
      for(unsigned int i = 0; i < n_graphs; ++i){
        idx3Dvec[i].push_back(idx3Dvecnew[i][cnt]);
        SpL3Dvec[i].push_back(SpL3Dvecnew[i][cnt]);
        esnmat[i].push_back(esnmatnew[i][cnt]);
      }
    }
  }
  if(mergeable){
    for(unsigned int i = 0; i < n_prunable_new; ++i){
      if(nodes_prunable[i] == parent_split_node){
        nodes_prunable[i] = node_split;
        n_splittable_vec_new[i] = (double) (n_splittable_new - splittable_children_cnt + 1.0);
        // MeLvec[i] = MeLik(Gs, Hs, muhat, train_cids, node_split, lgw, n_splittable_vec_new[i], 
        //                    n_prunable_new, splittable_children_cnt, tausq, alpha, beta, mu0, rb, 1 - rb);   
        MeLvec[i] = MeLik(node_split, lgw, n_splittable_vec_new[i], n_prunable_new, log_S, rb, 1 - rb);        
      }else{
        double diff = std::log((double) n_prunable_new) - std::log((double) n_prunable)
                    + std::log((double) n_splittable_vec_new[i]) 
                    - std::log((double) n_splittable_vec[i]);
        MeLvec[i] -= diff;
      }
    }
  }else{
    for(unsigned int i = 0; i < n_prunable_new; ++i){
      if(i == (n_prunable_new-1)){
        nodes_prunable.push_back(node_split);
        n_splittable_vec_new.push_back((double) (n_splittable_new - splittable_children_cnt + 1.0));
        // double log_M = MeLik(Gs, Hs, muhat, train_cids, node_split, lgw, n_splittable_vec_new[i], 
        //                    n_prunable_new, splittable_children_cnt, tausq, alpha, beta, mu0, rb, 1 - rb);  
        double log_M = MeLik(node_split, lgw, n_splittable_vec_new[i], n_prunable_new, log_S, rb, 1 - rb);
        MeLvec.push_back(log_M);              
      }else{
        double diff = std::log((double) n_prunable_new) - std::log((double) n_prunable)
                    + std::log((double) n_splittable_vec_new[i]) 
                    - std::log((double) n_splittable_vec[i]);
        MeLvec[i] -= diff;
      }
    }
  }
  nodes_splittable_new.clear(); 
  n_prunable_vec = n_prunable_vec_new; n_prunable = n_prunable_new;
  n_splittable_vec = n_splittable_vec_new; n_splittable = n_splittable_new;
  return(stop_update);
}

void MergeAdj(std::vector<OST> &graphs, tree &Ptree, const arma::vec &Gs, const arma::vec &Hs, const arma::vec &muhat, arma::vec &muhat_new, 
              arma::vec &muhat_ho_new, arma::uvec &train_cids, arma::uvec &test_cids, std::vector<std::vector<std::vector<double>>> &SpL3Dvec, 
              std::vector<std::vector<std::vector<unsigned int>>> &idx3Dvec, std::vector<std::vector<unsigned int>> &esnmat, std::vector<double> &MeLvec, 
              std::vector<double> &lgw, std::vector<double> &muvec, std::vector<double> &n_splittable_vec, std::vector<double> &n_prunable_vec,
              tree::npv &nodes_splittable, tree::npv &nodes_prunable, unsigned int &n_splittable, unsigned int &n_prunable, const unsigned int &node_prune_id,
              const double &alpha, const double &beta,  const unsigned int &max_depth, const double &tausq, const double &mu0, const unsigned int &split_eps,  
              const double &rb, rn &gen){           
  tree::tree_p node_prune = nodes_prunable[node_prune_id];   
  nodes_prunable.erase(nodes_prunable.begin()+node_prune_id);
  std::vector<double> n_splittable_vec_new = n_splittable_vec;
  n_splittable_vec_new.erase(n_splittable_vec_new.begin()+node_prune_id);
  MeLvec.erase(MeLvec.begin()+node_prune_id);
  unsigned int n_graphs = idx3Dvec.size(); 
  tree::tree_p cl = node_prune->getl(); tree::tree_p cr = node_prune->getr();
  unsigned int lidl = cl->getlid(); unsigned int lidr = cr->getlid();
  unsigned int ltyl = cl->getlty(); unsigned int ltyr = cr->getlty();
  arma::uvec train_ids_l = arma::find(train_cids == lidl); 
  arma::uvec train_ids_r = arma::find(train_cids == lidr);
  arma::uvec test_ids_l = arma::find(test_cids == lidl);
  arma::uvec test_ids_r = arma::find(test_cids == lidr);
  arma::uvec train_ids = arma::join_cols(train_ids_l, train_ids_r);
  arma::uvec test_ids = arma::join_cols(test_ids_l, test_ids_r);
  train_cids.elem(train_ids_r).fill(lidl);
  arma::uvec train_ids_gr  = arma::find(train_cids > lidr);
  if(train_ids_gr.size() > 0){train_cids.elem(train_ids_gr) -= 1;}
  if(test_ids_r.size()> 0){ test_cids.elem(test_ids_r).fill(lidl); }
  arma::uvec test_ids_gr = arma::find(test_cids > lidr);
  if(test_ids_gr.size() > 0){ test_cids.elem(test_ids_gr) -= 1; }
  unsigned int splittable_children_cnt = ((ltyl==0)+(ltyr == 0));
  unsigned int n_splittable_new = n_splittable - (splittable_children_cnt-1);
  std::transform(n_splittable_vec_new.begin(), n_splittable_vec_new.end(), 
                 n_splittable_vec_new.begin(), [splittable_children_cnt](double x)
                 { return x + 1.0 - splittable_children_cnt;});
  nodes_splittable.push_back(node_prune); tree::tree_p parent_node;
  tree::npv nodes_splittable_new; nodes_splittable_new.push_back(node_prune);
  std::vector<double> n_prunable_vec_new = n_prunable_vec;
  unsigned int n_prunable_new = n_prunable; bool mergeable = false;
  if(node_prune->ntype() != 't'){
    parent_node = node_prune->getp();
    if(parent_node->mtype() == 't'){
      mergeable = true; nodes_prunable.push_back(parent_node); 
    }
  }
  if(mergeable){
    tree::tree_p nl = parent_node -> getl(); tree::tree_p nr = parent_node -> getr(); 
    tree::tree_p nadd = (nl == node_prune)? (nr):(nl); 
    for(unsigned int i = 0; i < nodes_splittable.size(); i++){
      if(nodes_splittable[i] == nadd){ n_prunable_vec_new[i] -= 1; break; }
    }
  }else{
    std::transform(n_prunable_vec_new.begin(), n_prunable_vec_new.end(), 
                   n_prunable_vec_new.begin(), [](double x) { return x - 1.0;});
    n_prunable_new -= 1;   
  }
  int j =  n_splittable - 1;
  while(j>=0){
    if((nodes_splittable[j] == cl)||(nodes_splittable[j] == cr)){
      nodes_splittable.erase(nodes_splittable.begin() + j);
      n_prunable_vec_new.erase(n_prunable_vec_new.begin() + j);
      for(unsigned int i = 0; i < n_graphs; ++i){
        SpL3Dvec[i].erase(SpL3Dvec[i].begin() + j);
        idx3Dvec[i].erase(idx3Dvec[i].begin() + j);
        esnmat[i].erase(esnmat[i].begin() + j);
      }
    }else{
      double diff = std::log(n_prunable_vec_new[j]) - std::log(n_prunable_vec[j])
                  + std::log((double) n_splittable_new) - std::log((double) n_splittable);
      for(unsigned int i = 0; i < n_graphs; ++i){
        for (auto it = SpL3Dvec[i][j].begin(); it != SpL3Dvec[i][j].end(); ++it){ *it -= diff;}
      }
    }
    j--;
  }
  Ptree.deathp(node_prune); muvec.erase(muvec.begin() + lidr);
  muvec[lidl] = DrawMu(Ptree, Gs, Hs, muhat, muhat_new, muhat_ho_new, train_ids, test_ids, lidl, tausq, mu0, gen);
  std::sort(nodes_splittable.begin(), nodes_splittable.end(),
  [](const auto& a, const auto& b) { return (a->getlid()) < (b->getlid()); });
  tree::npv bottom_nodes; bottom_nodes.clear();
  Ptree.getbots(bottom_nodes);
  for(unsigned int i=0;i < bottom_nodes.size();i++){
    unsigned int lid = bottom_nodes[i]->getlid();
    if(lid > lidr){bottom_nodes[i]->setlid((lid-1));}
  }
  if(nodes_prunable.size()>0){
    for(unsigned int i = 0; i < nodes_prunable.size(); ++i){
      if(i == (n_prunable-1)){
        tree::tree_p nl = parent_node->getl(); tree::tree_p nr = parent_node->getr();
        unsigned int ltyl = nl->getlty(); unsigned int ltyr = nr->getlty();
        unsigned int splittable_cnt = (ltyl == 0) + (ltyr == 0);
        n_splittable_vec_new.push_back((double) (n_splittable_new + 1.0 - splittable_cnt));
        double tmp = MeLik(Gs, Hs, muhat, train_cids, parent_node, lgw, n_splittable_vec_new[i], 
                           n_prunable_new, splittable_cnt, tausq, alpha, beta, mu0, rb, 1 - rb);
        MeLvec.push_back(tmp);                  
      }else{
        double diff = std::log((double) n_prunable_new) - std::log((double) n_prunable)
                    + std::log((double) n_splittable_vec_new[i]) 
                    - std::log((double) n_splittable_vec[i]);
        MeLvec[i] -= diff;
      }
    }
  }
  std::vector<double> log_A_vec(1, 0); arma::uvec lidv(1, arma::fill::zeros);
  std::vector<double> log_prior_child_vec(1, 0);
  lidv(0) = nodes_splittable_new[0]->getlid();
  unsigned int node_depth = nodes_splittable_new[0]->depth();
  log_A_vec[0] = std::log(alpha) - beta * std::log(1.0 + node_depth) 
                - std::log(1.0 - alpha * std::pow((1.0 + node_depth), (-beta)));
  log_prior_child_vec[0] = std::log(1-alpha * std::pow((2.0 + node_depth), (-beta)));
  arma::uvec split_indices = find_indices(train_cids, lidv);
  arma::uvec train_cids_splittable = train_cids.elem(split_indices);
  arma::uvec train_cids_splittable_rank = get_ranks(train_cids_splittable);
  std::vector<std::vector<std::vector<double>>> SpL3Dvecnew(n_graphs, 
    std::vector<std::vector<double>>(1, std::vector<double>()));
  std::vector<std::vector<std::vector<unsigned int>>> idx3Dvecnew(n_graphs, 
    std::vector<std::vector<unsigned int>>(1, std::vector<unsigned int>()));
  std::vector<std::vector<unsigned int>> esnmatnew(n_graphs, std::vector<unsigned int>(1, 0)); 
  std::vector<double> log_n_prunable_vec(1, std::log((double) n_prunable));
  SpLik(graphs, Gs(split_indices), Hs(split_indices), muhat(split_indices), train_cids_splittable_rank, 
        log_n_prunable_vec, lgw, log_A_vec, log_prior_child_vec, SpL3Dvecnew, idx3Dvecnew, esnmatnew, 
        split_indices, tausq, mu0, split_eps, n_splittable_new, rb, 1-rb);
  for (unsigned int k = 0; k < nodes_splittable.size(); ++k) {
    if(nodes_splittable[k] == node_prune){
      for(unsigned int i = 0; i < n_graphs; ++i){
        SpL3Dvec[i].insert(SpL3Dvec[i].begin() + k, SpL3Dvecnew[i][0]);
        idx3Dvec[i].insert(idx3Dvec[i].begin() + k,  idx3Dvecnew[i][0]);
        esnmat[i].insert(esnmat[i].begin() + k, esnmatnew[i][0]);
      }
      n_prunable_vec_new.insert(n_prunable_vec_new.begin() + k, (double) n_prunable);
      break;
    }
  }
  nodes_splittable_new.clear(); 
  n_prunable_vec = n_prunable_vec_new; n_prunable = n_prunable_new; 
  n_splittable_vec = n_splittable_vec_new; n_splittable = n_splittable_new;
}

unsigned int MoveSelect(std::vector<double>& select_prob, double &norm_logweight, rn &gen){
  std::for_each(select_prob.begin(), select_prob.end(), [](double& val) {
        val /= 2.0;
  });
  double totalsum = 0.0;
  double max_val = *std::max_element(select_prob.begin(), select_prob.end());
  std::for_each(select_prob.begin(), select_prob.end(), [max_val](double& val){
        val -= max_val;
  });
  // for(unsigned int i=0;i<v.size();i++) if(v[i]>mx) mx=v[i];
  for(unsigned int i=0;i<select_prob.size();i++){
    totalsum += std::exp(select_prob[i]);
  }
  norm_logweight = std::log(totalsum) + max_val;
  std::for_each(select_prob.begin(), select_prob.end(), [totalsum](double& val) {
    val -= totalsum; val = std::exp(val);
  });
  gen.set_wts(select_prob); unsigned int select_idx = gen.discrete();
  return(select_idx);
}

unsigned int TreeSelect(std::vector<double>& tree_prob, double &logimpsum, rn &gen){
  double max_val = *std::max_element(tree_prob.begin(), tree_prob.end());
  std::for_each(tree_prob.begin(), tree_prob.end(), [max_val](double& val){
        val -= max_val;
  });
  double totalsum = 0.0;
  for(unsigned int i=0;i<tree_prob.size();i++){
    totalsum += std::exp(tree_prob[i]);
  }
  logimpsum = std::log(totalsum) + max_val;
  std::for_each(tree_prob.begin(), tree_prob.end(), [totalsum](double& val) {
    val -= totalsum; val = std::exp(val);
  });
  gen.set_wts(tree_prob); unsigned int select_idx = gen.discrete();
  return(select_idx);
}

void ProposeMove(std::vector<OST> &graphs, const arma::vec &Gs, const arma::vec &Hs, const arma::vec &Y, arma::vec &phi, 
                 arma::vec &phi_ho, arma::vec &muhat, arma::vec &muhat_ho, arma::uvec &train_cids, arma::uvec &test_cids,
                 tree &Ptree, std::vector<double> &lgw, std::vector<double> &muvec, const unsigned int &tree_iter, 
                 const unsigned int &max_depth, const double &tausq, const double &alpha, const double &beta, const double &mu0, 
                 const unsigned int &split_eps, const double &rb, const int &model, rn& gen){
  unsigned int n_graphs =  graphs.size(); tree::npv nodes_splittable; 
  nodes_splittable.clear(); bool stop_update = false;
  tree::tree_p node_split = nullptr; 
  tree::tree_p node_prune = nullptr;  
  Ptree.getsbots(nodes_splittable); 
  unsigned int fluc_cnt = 0; char move_type = 's'; 
  double logimpsum = - std::numeric_limits<double>::infinity(); 
  double norm_logweight = 0.0; unsigned int n_splittable = 1;
  std::sort(nodes_splittable.begin(), nodes_splittable.end(),
  [](const auto& a, const auto& b) { return (a->getlid()) < (b->getlid()); });
  std::vector<double> n_prunable_vec(n_splittable, 0); 
  std::vector<double> n_splittable_vec;
  tree::npv nodes_prunable; nodes_prunable.clear(); 
  unsigned int n_prunable = 0;
  std::vector<double> log_A_vec(n_splittable, 0); 
  arma::uvec lidv(n_splittable, arma::fill::zeros);
  std::vector<double> log_prior_child_vec(n_splittable, 0);
  lidv(0) = nodes_splittable[0]->getlid();
  unsigned int node_depth = nodes_splittable[0]->depth();
  log_A_vec[0] = std::log(alpha) - beta * std::log(1.0 + node_depth) 
               - std::log(1.0 - alpha * std::pow((1.0 + node_depth), (-beta)));
  log_prior_child_vec[0] = std::log(1-alpha * std::pow((2.0 + node_depth), (-beta)));
  n_prunable_vec[0] = (double) n_prunable + 1.0;
  arma::uvec split_indices = find_indices(train_cids, lidv);
  std::vector<std::vector<std::vector<double>>> SpL3Dvec(n_graphs, 
    std::vector<std::vector<double>>(n_splittable, std::vector<double>()));
  std::vector<std::vector<std::vector<unsigned int>>> idx3Dvec(n_graphs, 
    std::vector<std::vector<unsigned int>>(n_splittable, std::vector<unsigned int>()));
  std::vector<std::vector<unsigned int>> esnmat(n_graphs, std::vector<unsigned int>(n_splittable, 0)); 
  std::vector<double> log_n_prunable_vec(n_splittable, 0.0); std::vector<double> MeLvec(n_prunable); 
  tree Ptree_select; std::vector<double> muvec_select; 
  arma::vec phi_select; arma::vec phi_ho_select;
  arma::vec muhat_select; arma::vec muhat_ho_select;
  arma::vec muhat_new = muhat; arma::vec muhat_ho_new = muhat_ho;
  SpLik(graphs, Gs, Hs, muhat, train_cids, log_n_prunable_vec, lgw, log_A_vec, log_prior_child_vec,
        SpL3Dvec, idx3Dvec, esnmat, split_indices, tausq, mu0, split_eps, n_splittable, 1, 1-rb);
  muvec[0] = DrawMu(Ptree, Gs, Hs, muhat, muhat_new, muhat_ho_new, arma::find(train_cids==0), 
                    arma::find(test_cids==0), 0, tausq, mu0, gen);
  for(unsigned int i = 0; i < tree_iter; i++){
    unsigned int select_idx = 0; std::vector<double> select_prob = flatten(SpL3Dvec);
    if(MeLvec.size()>0){select_prob.insert(select_prob.end(), MeLvec.begin(), MeLvec.end());}
    select_idx =  MoveSelect(select_prob, norm_logweight, gen);
    DEBUG_MSG("Done select Proposal");
    std::vector<unsigned int> graph_move_cnt = RowSums(esnmat);
    unsigned int split_merge_thres = std::accumulate(graph_move_cnt.begin(), graph_move_cnt.end(), 0);
    arma::vec phi_tmp = phi + muhat_new; 
    arma::vec phi_ho_tmp = phi_ho + muhat_ho_new; 
    double logimp = LogimpWeight(Y, phi, phi_tmp, norm_logweight, model);
    std::vector<double> logimpvec = {logimp, logimpsum};
    unsigned int select_tree = TreeSelect(logimpvec, logimpsum, gen); 
    if(select_tree==0){
      Ptree_select = Ptree; muvec_select = muvec;
      phi_select = phi_tmp; phi_ho_select = phi_ho_tmp; 
      muhat_select = muhat_new; muhat_ho_select = muhat_ho_new;
    }
    if(select_idx < split_merge_thres){
      unsigned int node_split_id = 0; unsigned int v = 0; //split variable, start from 0
      int cnt = select_idx - graph_move_cnt[v]; //cut splittable edge idx, start from 0
      while(cnt>=0){ v++; cnt -= graph_move_cnt[v]; }
      cnt += graph_move_cnt[v]; cnt -= esnmat[v][0];
      while(cnt>=0){ node_split_id++; cnt -= esnmat[v][node_split_id]; }
      cnt += esnmat[v][node_split_id];
      unsigned int edge_id = idx3Dvec[v][node_split_id][cnt];
      double log_S = SpL3Dvec[v][node_split_id][cnt];
      node_split = nodes_splittable[node_split_id];  
      if((move_type == 'm')&&(node_split==node_prune)){fluc_cnt += 1;}
      else{fluc_cnt = 0; node_prune = nullptr; } move_type = 's'; 
      stop_update = SplitAdj(graphs, Ptree, Gs, Hs, muhat, muhat_new, muhat_ho_new, train_cids, test_cids, SpL3Dvec, log_S, idx3Dvec, 
                             esnmat, MeLvec, lgw, muvec, n_splittable_vec, n_prunable_vec, nodes_splittable, nodes_prunable,
                             n_splittable, n_prunable, v, edge_id, node_split_id, alpha, beta, max_depth, tausq, mu0, split_eps, rb, gen);
      DEBUG_MSG("Done Split");
      if((stop_update)||(fluc_cnt >= 5)){
        Ptree = Ptree_select; muvec = muvec_select;
        phi = phi_select; phi_ho = phi_ho_select; 
        muhat = muhat_select; muhat_ho = muhat_ho_select;
        return;
      }
    }else{
      unsigned int node_prune_id = select_idx - split_merge_thres;
      node_prune = nodes_prunable[node_prune_id];   
      if((move_type == 's')&&(node_split==node_prune)){fluc_cnt += 1;}
      else{fluc_cnt = 0; node_split = nullptr;} move_type = 'm'; 
      MergeAdj(graphs, Ptree, Gs, Hs, muhat, muhat_new, muhat_ho_new, train_cids, test_cids, SpL3Dvec, idx3Dvec, esnmat, MeLvec, 
               lgw, muvec, n_splittable_vec, n_prunable_vec, nodes_splittable, nodes_prunable, n_splittable,
               n_prunable, node_prune_id, alpha, beta, max_depth, tausq, mu0, split_eps, rb, gen);
    }
  }
  Ptree = Ptree_select; muvec = muvec_select;
  phi = phi_select; phi_ho = phi_ho_select; 
  muhat =  muhat_select; muhat_ho = muhat_ho_select;
  return;
}

// TaylorExpansion calGradients_gaussian(const arma::vec &Y, const arma::vec &phi, const double &sigmasq){
//   const unsigned int n = Y.n_elem;
//   arma::vec Gs((Y - phi)/sigmasq);
//   arma::vec Hs(n, arma::fill::value(-1.0/sigmasq));
//   return(std::make_pair(Gs, Hs));
// }

TaylorExpansion calGradients_binary(const arma::vec &Y, const arma::vec &phi){
  arma::vec p = 1.0/(1.0 + arma::exp(-1.0*phi));
  arma::vec Gs = Y - p;
  arma::vec Hs = -p%(1.0 - p);
  return(std::make_pair(Gs, Hs));
}

TaylorExpansion calGradients_var(const arma::vec &Y, const arma::vec &phi){
  arma::vec tmp = arma::exp(phi);
  tmp.elem(arma::find(tmp<1e-6)).fill(1e-6);
  arma::vec Gs = -0.5 - 0.5 * tmp + (arma::square(Y))/(2 * tmp);
  arma::vec Hs = -(arma::square(tmp) + arma::square(Y))/(2 * tmp);
  return(std::make_pair(Gs, Hs));
}

double drtausq(const std::vector<double> &mu_vec, const double &a, const double &b, const double  &mu0, rn& gen){
  double sum_of_squares = 0.0;
  unsigned int total_elements = mu_vec.size();
  for (double val : mu_vec) {
    double diff = val - mu0;
    sum_of_squares += diff * diff;
  }
  double tausq =  1/gen.gamma((total_elements + a)/2, (sum_of_squares + b)/2);
  return(tausq);
}

// void drsigmasq(const arma::vec &Y, const arma::vec &phi, double &sigmasq, const double &nu, const double &lambda, rn& gen){
//   int n_train = Y.n_elem;
//   double sse = arma::accu(arma::square(Y - phi));
//   sigmasq = 1/gen.gamma(0.5*(n_train + nu), 0.5*(lambda*nu + sse));
// }

double LogimpWeight(const arma::vec &Y, const arma::vec &exnpoi, const arma::vec &phi, const double norm_logweight, const int model){
  double logweight = 0.0;
  if(model == 1){ 
    arma::vec p = 1.0/(1.0 + arma::exp(-1.0*exnpoi)); 
    arma::vec p_new = 1.0/(1.0 + arma::exp(-1.0*phi));
    arma::vec log_truedist = Y % (arma::log(p_new)) + (1.0 - Y) % (arma::log(1.0 - p_new));
    arma::vec log_approxidist = Y % (arma::log(p)) + (1.0 - Y) % (arma::log(1.0 - p)) +
                              + (phi - exnpoi) % (Y - p) + 0.5 * arma::square(phi - exnpoi) % (-p%(1.0 - p));
    logweight = arma::accu(log_truedist - log_approxidist) - norm_logweight;
  }else if(model == 2){
    arma::vec expl = arma::exp(exnpoi); arma::vec expl_new = arma::exp(phi); 
    expl_new.elem(arma::find(expl_new<1e-2)).fill(1e-2); 
    expl.elem(arma::find(expl<1e-2)).fill(1e-2); 
    arma::vec log_truedist = - arma::square(Y - expl_new) / (2 * expl_new) - 0.5 * phi;
    arma::vec log_approxidist = - arma::square(Y - expl) / (2 * expl) - 0.5 * exnpoi 
                              + (phi - exnpoi) % (arma::square(Y)/(2.0 * expl) - 0.5 * (1.0 + expl)) 
                              + 0.5 * arma::square(phi - exnpoi) % (- arma::square(Y)/(2.0 * expl) - 0.5 * expl);
    logweight = arma::accu(log_truedist - log_approxidist) - norm_logweight;
  }
  return(logweight);
}


//draw variable splitting probabilities from Dirichlet (Linero, 2018)
void draw_s(std::vector<unsigned int>& nv, std::vector<double>& lpv, double& theta, rn& gen){
  size_t p=nv.size();
// Now draw s, the vector of splitting probabilities
  std::vector<double> _theta(p);
  for(size_t j=0;j<p;j++) _theta[j]=theta/(double)p+(double)nv[j];
  //gen.set_alpha(_theta);
  lpv=gen.log_dirichlet(_theta);
}

//--------------------------------------------------
//draw Dirichlet sparsity parameter from posterior using grid
void draw_theta0(bool const_theta, double& theta, std::vector<double>& lpv,
		 double eta, double zeta, double rho, rn& gen){
  // Draw sparsity parameter theta_0 (Linero calls it alpha); see Linero, 2018
  // theta / (theta + rho ) ~ Beta(nu,xi)
  // Set (eta=0.5, zeta=1) for sparsity
  // Set (eta=1, zeta=1) for non-sparsity
  // rho = p usually, but making rho < p increases sparsity
  if(!const_theta){
    size_t p=lpv.size();
    double sumlpv=0.,lse;
    std::vector<double> lambda_g (1000,0.);
    std::vector<double> theta_g (1000,0.);
    std::vector<double> lwt_g (1000,0.);
    for(size_t j=0;j<p;j++) sumlpv+=lpv[j];
    for(size_t k=0;k<1000;k++){
      lambda_g[k]=(double)(k+1)/1001.;
      theta_g[k]=(lambda_g[k]*rho)/(1.-lambda_g[k]);
      double theta_log_lik=lgamma(theta_g[k])-(double)p*lgamma(theta_g[k]/(double)p)+(theta_g[k]/(double)p)*sumlpv;
      double beta_log_prior=(eta-1.)*log(lambda_g[k])+(zeta-1.)*log(1.-lambda_g[k]);
//      cout << "SLP: " << sumlogpv << "\nTLL: " << theta_log_lik << "\nBLP: " << beta_log_prior << '\n';
      lwt_g[k]=theta_log_lik+beta_log_prior;
    }
    lse=log_sum_exp2(lwt_g);
    for(size_t k=0;k<1000;k++) {
      lwt_g[k]=exp(lwt_g[k]-lse);
//      cout << "LWT: " << lwt_g[k] << '\n';
    }
    gen.set_wts(lwt_g);
    theta=theta_g[gen.discrete()];
  }
}
