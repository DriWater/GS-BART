#pragma once

#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

#include <vector>
#include <valarray>
#include <algorithm>
#include <iterator>
#include <unordered_map>
#include <string>
#include <ostream>
#include <cstddef>
// [[Rcpp::plugins(cpp17)]]  
#include <any>
#include <stack>
#ifdef _OPENMP
#include <omp.h>
#endif
// [[Rcpp::plugins(openmp)]]

#include "debug_msg.h"

template<typename T>
std::vector<T> slice(const std::vector<T>& v, const std::vector<unsigned int>& id);
template<typename T>
std::valarray<T> slice(const std::valarray<T>& v, const std::valarray<unsigned int>& id);

// Contains the vertex attributes we desire
class Vertex {
public:
  
  Vertex(const arma::uvec &mesh2tr_inp, const arma::uvec &mesh2ho_inp) {
    mesh2tr = arma::uvec{mesh2tr_inp};
    mesh2ho = arma::uvec{mesh2ho_inp};
  }

  arma::uvec mesh2tr;
  arma::uvec mesh2ho;
};


class OST {
public:

  OST(const std::vector<std::vector<unsigned int> > &childrenList, 
            const std::vector<std::vector<unsigned int> > &mesh2tr, 
            const std::vector<std::vector<unsigned int> > &mesh2ho,
            const std::vector<unsigned int> &tr2mesh, 
            // const std::vector<unsigned int> &ho2mesh, 
            const std::vector<unsigned int> &root) {
    roots.assign(root.begin(), root.end());
    unsigned int n_verts = childrenList.size();
    for(unsigned int i = 0; i < n_verts; ++i) {
      children.emplace_back(childrenList[i]);
      nodes.emplace_back(
        arma::uvec(mesh2tr[i]),
        arma::uvec(mesh2ho[i])
      );
    }
    attributes.insert(std::make_pair<std::string, std::vector<unsigned int>>("tr2mesh", std::vector(tr2mesh)));
    // attributes.insert(std::make_pair<std::string, std::vector<unsigned int>>("ho2mesh", std::vector(ho2mesh)));
  }
  
  OST(const std::vector<std::vector<unsigned int> > &childrenList, 
            const std::vector<std::vector<unsigned int> > &mesh2tr, 
            const std::vector<unsigned int> &tr2mesh, 
            // const std::vector<unsigned int> &ho2mesh, 
            const std::vector<unsigned int> &root) {
    roots.assign(root.begin(), root.end());
    unsigned int n_verts = childrenList.size();
    for(unsigned int i = 0; i < n_verts; ++i) {
      children.emplace_back(childrenList[i]);
      nodes.emplace_back(
        arma::uvec(mesh2tr[i]),
        arma::uvec(0u)
      );
    }
    attributes.insert(std::make_pair<std::string, std::vector<unsigned int>>("tr2mesh", std::vector(tr2mesh)));
  }

  unsigned int numVerts() const {
    return(nodes.size());
  }
  
  unsigned int numRoots() const {
    return(roots.size());
  }
  
  const std::vector<unsigned int>& getRoots() const {
    return(roots);
  }
  
  bool isRoot(unsigned int e) const {
    return(std::find(roots.begin(), roots.end(), e) != roots.end());
  }
  
  unsigned int numChildren(unsigned int v) const {
    return(children[v].size());
  }
  
  unsigned int getChild(unsigned int v, unsigned int child_idx) const {
    return(children[v][child_idx]);
  }

  unsigned int numTest() const{
    unsigned int n = 0;
    for(const auto& node : nodes) {
      n += node.mesh2ho.size();
    }
    return n;
  }
  
  /*
  unsigned int getParent(unsigned int child_idx) const {
    unsigned int parent_idx = nodes.size();
    bool found_parent = false;
    //#ifdef _OPENMP
    //#pragma omp parallel for schedule(static)
    //#endif
    for (unsigned int i = 0; i < nodes.size() && !found_parent; ++i) {
      const auto& childrens = children[i];
      for (unsigned int j = 0; j < childrens.size(); ++j) {
        if (childrens[j] == child_idx) {
              //#ifdef _OPENMP
              //#pragma omp critical
              //#endif
              {
                if (!found_parent) {
                  parent_idx = i;
                  found_parent = true;
                }
              }
            }
          }
        }
    return parent_idx;
  }
  */
 
  template<typename T>
  T getGraphAttr(const std::string name) {
    // if(attributes.count(name) == 0) {
    //   Rcpp::stop("Error: tried to access uninitialized graph attribute");
    // }
    return std::any_cast<T>(attributes.at(name));
  }
  
  template<typename T>
  void addGraphAttr(std::string name, T value) {
    attributes.insert(std::make_pair<std::string, T>(name, value));
  }
  
  // like Split_OST + updates all ids/test_ids together; *modifies ids and test_ids in place*
  void splitIndices(unsigned int split_id, unsigned int split_class, 
             arma::uvec &ids, arma::uvec &test_ids, unsigned int nc) {
   // This section replicates Split_OST
   /*
   unsigned int v_j = getParent(split_id);
   DEBUG_MSG("Splitting split_id " << split_id << ", split_class " << split_class
                                   << ", parent node has id " << v_j);
   roots.push_back(split_id);
   if(children[v_j].size() == 1) {
     children[v_j].clear();
   } else {
     children[v_j].erase(std::find(children[v_j].begin(), children[v_j].end(), split_id));
   }
   DEBUG_MSG("Finished Split_OST");
    */
   // This section updates ids and test_ids
   unsigned int n_ho = test_ids.n_elem;
   std::stack<unsigned int> stack;
   stack.push(split_id);
   while(!stack.empty()) {
     unsigned int vv = stack.top();
     stack.pop();
     arma::uvec ids_vv(nodes[vv].mesh2tr);
     arma::uvec test_ids_vv(nodes[vv].mesh2ho);
     //DEBUG_MSG("ids (" << ids.size() << ") :" << std::endl << ids);
     //DEBUG_MSG("test_ids (" << test_ids.size() << ") :" << std::endl << test_ids);
     //DEBUG_MSG("ids_vv (" << ids_vv.size() << ") :" << std::endl << ids_vv);
     //DEBUG_MSG("test_ids_vv (" << test_ids_vv.size() << ") :" << std::endl << test_ids_vv);

     arma::uvec matching_ids(arma::find(ids.elem(ids_vv) == split_class));
     arma::uvec ids_node_vv(ids_vv.elem(matching_ids));
     if(ids_node_vv.size() > 0) { ids(ids_node_vv).fill(nc); }
     if(n_ho > 0) {
      arma::uvec test_matching_ids(arma::find(test_ids.elem(test_ids_vv) == split_class));
     //DEBUG_MSG("matching_ids (" << matching_ids.size() << ") :" << std::endl << matching_ids);
     //DEBUG_MSG("test_matching_ids (" << test_matching_ids.size() << ") :" << std::endl << test_matching_ids);
      arma::uvec test_ids_node_vv(test_ids_vv.elem(test_matching_ids));
      if(test_ids_node_vv.size() > 0) { test_ids(test_ids_node_vv).fill(nc); }
     }
     for(unsigned int i = 0; i < children[vv].size(); ++i) {
       stack.push(children[vv][i]);
     }
    }
   //DEBUG_MSG("Finished updating ids and test_ids");
  }
  
  void print(std::ostream &os) {
    os << "roots: \n";
    for(unsigned int r : roots) {
      os << r << ", ";
    }
    os << "\nchildren: \n";
    int i = 0;
    for(auto vec : children) {
      os << i << ":\n  ";
      for(unsigned int child : vec) {
        os << child << ", ";
      }
      ++i;
    }
    os << "\nnodes: \n";
    i = 0;
    for(Vertex node : nodes) {
      os << i << ":\n  ";
      os << "mesh2tr: " << node.mesh2tr << "\n";
      os << "mesh2ho: " << node.mesh2ho << "\n";
      ++i;
    }
  }
  
protected:
  // Id of each root in the tree (length numRoots)
  std::vector<unsigned int> roots;
  // Ids of each child of each node (outer length numVerts)
  std::vector<std::vector<unsigned int> > children;
  // Mapping ids to actual node values (length numVerts); equivalent to vertex attributes
  std::vector<Vertex> nodes;
  // Graph attributes (not tied to vertices directly)
  std::unordered_map<std::string, std::any> attributes;
};




