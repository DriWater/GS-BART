#' Fit Multinomial Model via GSBart
#'
#' @description Fits a multinomial model using Generalized Spanning Bayesian Additive Regression Trees (GSBart).
#'
#' @param Y_train Numeric vector of length `n_train`, representing the training response.
#' @param Graphs List of length `n_rounds`, where each element is a list of length `n_graphs`. Each element
#' contains information about a Root-Oriented Spanning Tree (ROST). Typically, `n_graphs` corresponds
#' to the number of features/parameters. Assumes all vertex IDs are 1-indexed and sequential (as generated
#' by the \code{igraph} package).
#'
#' Each graph in `Graphs` includes:
#' \itemize{
#'   \item `root`: Numeric vector identifying the vertex ID(s) acting as the root(s) of the ROST.
#'   \item `children`: Graph adjacency list of length equal to the number of vertices (`n_verts`). Each element
#'     contains vertex IDs of the children of the corresponding vertex.
#'   \item `g`: An \code{igraph} object with the following attributes:
#'   \item `mesh2tr`: List of length `n_verts`, mapping each vertex to elements of the training response.
#'   \item `mesh2ho`: (Optional) List of length `n_verts`, mapping each vertex to elements of the testing response.
#'   Graph attributes include:
#'   \item `tr2mesh`: Numeric vector of length `n_train`, mapping training response elements to vertices.
#' }
#' @param ndpost Integer, number of post-burn-in iterations.
#' @param nskip Integer, number of burn-in iterations.
#' @param nkeep Integer, number of post-burn-in draws to retain. Defaults to `ndpost` * `n_graphs`.
#' @param graphs_weight Numeric vector specifying the importance weight for each graph. Default is `1 / n_graphs`.
#' @param hyperpar (Optional) List of hyperparameters. Each element is optional:
#' \itemize{
#'   \item `alpha`: Numeric, controls tree depth (P(split) = alpha (1 + depth)^(-beta)). Default: 0.95.
#'   \item `beta`: Numeric, controls tree depth (P(split) = alpha (1 + depth)^(-beta)). Default: 2.
#'   \item `a`: Numeric, shape parameter of the inverse gamma prior for leaf weight variance. Default: 5.
#'   \item `b`: Numeric, scale parameter of the inverse gamma prior for leaf weight variance. Default: 0.5 / length(Graphs).
#'   \item `split_eps`: Integer, the minimum cluster size must be greater than `split_eps + 1`. Default: 0.
#'   \item `max_depth`: Integer, maximum tree depth. Default: 6.
#'   \item `rb`: Numeric, prior probability of a split proposal. Default: 0.5.
#'   \item `nu`: Numeric, degrees of freedom for error variance prior (Gaussian only).
#'   \item `lambda`: Numeric, scale parameter for error variance prior (Gaussian only).
#'   \item `mu0`: Numeric, estimated mean of predicted leaf weight.
#'   \item `eta`: Numeric, Sparse parameter for Beta(eta, zeta) prior: 0.5 <= eta <= 1, where lower values inducing more sparsity.
#'   \item `zeta`: Numeric, Sparse parameter for Beta(eta, zeta) prior: typically, zeta = 1.
#'   \item `rho`: Numeric, Sparse parameter: typically rho = p, where p is the number of candidate graphs.
#'   \item `tree_iter`: Integer, maximum iterations for training each tree. Default: 12.
#' }
#' @param modelpar (Optional) List of model parameters. Each element is optional:
#' \itemize{
#'   \item `tausq`: Numeric, prior for leaf weight variance.
#'   \item `theta`: Numeric, Set theta parameter, 0 means random.
#' }
#' @param nthreads Integer, number of OpenMP threads to use. Default: 1 (sequential execution).
#' @param sparse Logical, if TRUE, uses the DART algorithm for training. Default: FALSE.
#' @param verbose Logical, if TRUE, prints diagnostic information during training. Default: FALSE.
#' @param  seed Integer, random seed for reproducibility. Default: NULL.
#'
#' @return A list containing:
#' \itemize{
#'   \item `prob.train`: Numeric matrix (`n_train` x `ndpost`), estimated probabilities P(Y = k | x_train).
#'   \item `prob.test`: (If applicable) Numeric matrix (`n_test` x `ndpost`), estimated probabilities P(Y = k | x_test).
#'   \item `prob.train.mean`: Numeric vector (`n_train`), mean estimated probabilities for training data.
#'   \item `prob.test.mean`: (If applicable) Numeric vector (`n_test`), mean estimated probabilities for testing data.
#'   \item `yhat.train`: Numeric vector, predicted categorical values for training data.
#'   \item `yhat.test`: Numeric vector, predicted categorical values for testing data.
#'   \item `tau`: List of numeric vectors (`nskip + ndpost`), estimated leaf weight standard deviations.
#'   \item `varcount`: List of matrices (`ndpost` x `n_graphs`), variable usage counts for decision rules.
#'   \item `tree.draws.list`: List of character strings, sequences of decision tree splits for each category.
#' }
#'
#' @export
#' @import parallel
#'
#' @examples
#'\dontrun{
#' data(sim)
#' fitmodel = mgsbart2(sim$multi_Y, sim$Graphs, ndpost = 25, nskip = 15,
#'   nkeep = ndpost*length(Graphs), graphs_weight = sim$graphs_weight, nthreads = 5,
#'   dart = FALSE, const_theta = TRUE, verbose=FALSE)
#' print(mean(sim$multi_Y_ho == fitmodel$yhat.test))
#' }
#'
mgsbart2 <- function(Y_train, Graphs, ndpost, nskip, nkeep = ndpost*length(Graphs), graphs_weight = rep(1/length(Graphs[[1]]), length(Graphs[[1]])),
                     hyperpar = NULL, modelpar = NULL, nthreads = 0, sparse = FALSE, verbose = FALSE, seed = 1234){
  pred_flag = !is.null(Graphs[[1]][[1]]$mesh2ho)
  cats <- sort(unique(Y_train))
  K <- length(cats)
  ntrees = length(Graphs)
  if(K<2)
    stop("there must be at least 2 categories")
  post <- list()
  post$K <- K
  post$cats <- cats
  nthreads  = min(nthreads, parallel::detectCores(logical = FALSE))
  N <- length(Y_train)
  post$phi.train <- matrix(nrow=nkeep, ncol=N*K)
  post$prob.train <- matrix(nrow=nkeep, ncol=N*K)
  # post$tot.train <- matrix(0, nrow=nkeep, ncol=N)
  if(pred_flag) {
    Q <- length(do.call('c', Graphs[[1]][[1]]$mesh2ho))
    # Q <- length(InputGraphs[[1]][[1]]$ho2mesh)
    post$phi.test <- matrix(0, nrow=nkeep, ncol=Q*K)
    post$prob.test <- matrix(0, nrow=nkeep, ncol=Q*K)
    # post$tot.test <- matrix(0, nrow=nkeep, ncol=Q)
  }
  post$varcount <- as.list(1:K)
  # post$varimp <- matrix(nrow=K, ncol=P)
  post.list <- as.list(1:K)
  post$tau <- as.list(1:K)
  post$tree.draws.list <- as.list(1:K)
  # Define the function
  IterFun <- function(h, nthreads){
      Y_train_h = (Y_train==cats[h])*1
      hyperpar_h = hyperpar
      modelpar_h = modelpar
      if(!is.null(hyperpar_h)){
        hyperpar_h_names = names(hyperpar_h)
        if(!("alpha" %in% hyperpar_h_names)){ hyperpar_h["alpha"] = 0.95}
        if(!("beta" %in% hyperpar_h_names)){hyperpar_h["beta"] = 2}
        if(!("a" %in% hyperpar_h_names)){hyperpar_h["a"] = 3}
        if(!("b" %in% hyperpar_h_names)){hyperpar_h["b"] = 0.5 * 6 / ntrees}
        if(!("split_eps" %in% hyperpar_h_names)){ hyperpar_h["split_eps"] = 0}
        if(!("max_depth" %in% hyperpar_h_names)){ hyperpar_h["max_depth"] = 6}
        if(!("rb" %in% hyperpar_h_names)){hyperpar_h["rb"] = 0.5}
        if(!("mu0" %in% hyperpar_h_names)){hyperpar_h["mu0"] =  stats::qlogis(mean(Y_train_h))/ntrees}
        if(!("eta" %in% hyperpar_h_names)){hyperpar_h["eta"] = 0.5}
        if(!("zeta" %in% hyperpar_h_names)){hyperpar_h["zeta"] = 1}
        if(!("rho" %in% hyperpar_h_names)){hyperpar_h["rho"] = length(Graphs[[1]])}
        if(!("tree_iter" %in% hyperpar_h_names)){hyperpar_h["tree_iter"] = 12}
      }else{
        hyperpar_h = list(alpha = 0.95, beta = 2, a = 3, b = 0.6, split_eps = 0, max_depth = 6,
                          rb = 0.5, mu0 = stats::qlogis(mean(Y_train_h))/ntrees, eta = 0.5,
                          zeta = 1, rho = length(Graphs[[1]]), tree_iter = 12)
      }
      if(!is.null(modelpar_h)){
        modelpar_names = names(modelpar_h)
        if(!("tausq" %in% modelpar_names)){modelpar_h["tausq"] = ((max(Y_train_h)-min(Y_train_h))/(2*2*sqrt(ntrees)))^2 }
        if(!("theta" %in% modelpar_names)){modelpar_h["theta"] = 0}
      }else{
        modelpar_h = list("tausq" = ((max(Y_train)-min(Y_train))/(2*sqrt(ntrees)))^2,
                          "theta" = 0)
      }
      const_theta = T
      if(modelpar_h[['theta']] == 0){const_theta = F; modelpar_h[['theta']] = 1}
      ret = GenGSBart(Y_train_h, ndpost, nskip, nkeep, Graphs, graphs_weight, hyperpar_h, modelpar_h,
                      1, nthreads, pred_flag, sparse, const_theta, verbose, seed)
      return(ret)
  }
  os_type <- .Platform$OS.type
  if(os_type == "unix") {
    if(nthreads > K){
      post.list = lapply(1:K, IterFun, nthreads = nthreads)
    }else{
      post.list = parallel::mclapply(1:K, function(h){IterFun(h, 1)}, mc.cores = K)
    }
  }else if(os_type == "windows"){
    if(nthreads > K){
      post.list = lapply(1:K, IterFun, nthreads = nthreads)
    }else{
      cl <- parallel::makeCluster(nthreads)
      on.exit(parallel::stopCluster(cl))
      parallel::clusterExport(cl, varlist = c(
      "IterFun", "Y_train", "cats", "hyperpar", "modelpar", "Graphs", "graphs_weight",
      "ntrees", "ndpost", "nskip", "nkeep", "pred_flag", "sparse", "verbose", "seed", "GenGSBart"
      ), envir = environment())
      post.list = parallel::parLapply(cl, 1:K, function(h){IterFun(h, 1)})
    }
  }
  for(h in 1:K) {
    for(i in 1:N) {
      j <- (i-1)*K+h
      post$phi.train[ , j] <- post.list[[h]]$phi.train[ , i]
      if(h==K){
        maxvals = apply(post$phi.train[ ,(i-1)*K+1:K], 1, max)
        tot.train = apply(post$phi.train[ ,(i-1)*K+1:K], 1, function(x){
                          maxval <- max(x);  sum(exp(x - maxval))})
        post$prob.train[ , (i-1)*K+1:K] = exp(post$phi.train[, (i-1)*K+1:K]
                                        - maxvals)/tot.train
      }
    }
    if(pred_flag) {
      for(i in 1:Q) {
        j <- (i-1)*K+h
        post$phi.test[ , j] <- post.list[[h]]$phi.test[ , i]
        if(h==K){
          maxvals = apply(post$phi.test[ ,(i-1)*K+1:K], 1, max)
          tot.test = apply(post$phi.test[ ,(i-1)*K+1:K], 1, function(x){
                           maxval <- max(x);  sum(exp(x - maxval))})
          post$prob.test[ , (i-1)*K+1:K] = exp(post$phi.test[, (i-1)*K+1:K]
                                          - maxvals)/tot.test
        }
      }
    }
    post$varcount[[h]] <- post.list[[h]]$varcount
    post$tau[[h]] <- post.list[[h]]$tau
    post$tree.draws.list[[h]] <- post.list[[h]]$tree.draws
  }
  post$prob.train.mean <- apply(post$prob.train, 2, mean)
  post$yhat.train = max.col(matrix(post$prob.train.mean, ncol = K, byrow = T)) - 1
  post$call = call
  if(pred_flag) {
    post$prob.test.mean <- apply(post$prob.test, 2, mean)
    post$yhat.test = max.col(matrix(post$prob.test.mean, ncol = K, byrow = T)) - 1
  }
  return(post)
}
