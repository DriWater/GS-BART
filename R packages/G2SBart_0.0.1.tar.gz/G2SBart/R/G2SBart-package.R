#' @importFrom Rcpp evalCpp
#' @useDynLib G2SBart, .registration = TRUE
NULL
